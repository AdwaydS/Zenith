import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());

// Initialize Gemini Client
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;
if (apiKey) {
  ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Fallback bank for questions if API key is not configured or fails
const CURATED_AI_BANK = [
  {
    section: 'Quant',
    exam: 'CAT / XAT',
    difficulty: 'CAT 99.8%ile Master',
    title: 'Cyclic Polygonal Inradii & Optimization',
    text: 'A regular hexagon and an equilateral triangle share the exact same perimeter P. Let A_h and A_t represent their respective areas. If A_h - A_t = 18√3 cm², find the exact perimeter P in centimeters.',
    type: 'tita',
    correctAnswer: '36',
    explanation:
      'Let hexagon side = a, equilateral triangle side = b.\nSince perimeters are equal: P = 6a = 3b => b = 2a.\nArea of hexagon A_h = 6 × (√3/4)a² = (3√3/2)a².\nArea of triangle A_t = (√3/4)b² = (√3/4)(2a)² = √3 a².\nDifference: A_h - A_t = (3√3/2 - √3)a² = (√3/2)a².\nGiven (√3/2)a² = 18√3 => a² = 36 => a = 6 cm.\nPerimeter P = 6a = 36 cm.'
  },
  {
    section: 'DILR',
    exam: 'CAT / UPSC CSAT',
    difficulty: 'Complex Matrix Deduction',
    title: 'Multi-Floor Binary Assignment with Adjacency Penalties',
    text: 'Four consultants (P, Q, R, S) occupy 4 consecutive office suites (101 to 104). P is directly adjacent to Q. R refuses to occupy an odd-numbered suite. If S is strictly to the left of Q and Suite 102 is vacant for maintenance, which consultant must occupy Suite 104?',
    type: 'mcq',
    options: ['Consultant P', 'Consultant Q', 'Consultant R', 'Consultant S'],
    correctAnswer: 'Consultant R',
    explanation:
      'Even suites are 102 and 104. Since 102 is vacant, R must take 104 (the only available even suite). P, Q, and S occupy suites 101 and 103, satisfying S < Q and P adjacent to Q.'
  },
  {
    section: 'VARC',
    exam: 'CAT / XAT',
    difficulty: 'Critical Reasoning / Inference',
    title: 'Kahneman System 1 Bias in Market Inefficiencies',
    text: 'Which underlying assumption most critically bridges the premise of heuristics-driven asset mispricing to the conclusion that systematic algorithmic arbitrage cannot eliminate volatility?',
    type: 'mcq',
    options: [
      'Algorithmic trading models are themselves calibrated on historical heuristics-laden human transactions',
      'High-frequency market makers operate with unbounded risk tolerance',
      'Behavioral finance completely invalidates the Efficient Market Hypothesis in sovereign bond markets',
      'Information asymmetry decreases strictly monotonically as computational latency reaches zero'
    ],
    correctAnswer: 'Algorithmic trading models are themselves calibrated on historical heuristics-laden human transactions',
    explanation:
      'For algorithmic strategies to fail at dampening human heuristic volatility, the algorithms themselves must replicate or amplify the underlying biases through training dataset bias.'
  }
];

// Endpoint: Generate dynamic CAT question
app.post('/api/gemini/generate-question', async (req, res) => {
  try {
    const { section } = req.body;
    const targetSection = section && section !== 'All' ? section : 'Quant';

    if (ai) {
      const prompt = `Generate one brand new, authentic 99th-percentile CAT/XAT/UPSC-CSAT level problem for section: ${targetSection}.
Return strictly a valid JSON object matching this schema:
{
  "section": "${targetSection}",
  "exam": "CAT / XAT",
  "difficulty": "Hard (99%ile Tier)",
  "title": "Concise Descriptive Problem Title",
  "text": "Full problem description with rigorous numerical or logical constraints.",
  "type": "mcq",
  "options": ["Option A", "Option B", "Option C", "Option D"],
  "correctAnswer": "Option A",
  "explanation": "Deep conceptual shortcut, step-by-step resolution, and test-taking invariant."
}`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          systemInstruction:
            'You are the chief test maker for IIM CAT and UPSC CSAT. Craft questions with rigorous mathematical elegance, subtle traps, and deep conceptual shortcuts.',
        },
      });

      const text = response.text;
      if (text) {
        const parsed = JSON.parse(text);
        parsed.id = 'ai-gen-' + Date.now();
        return res.json(parsed);
      }
    }

    // Fallback if AI not available
    const matching = CURATED_AI_BANK.find((q) => q.section === targetSection) || CURATED_AI_BANK[0];
    const item = { ...matching, id: 'ai-gen-' + Date.now() };
    return res.json(item);
  } catch (err: any) {
    console.warn('Gemini question generation error, falling back:', err.message);
    const fallback = { ...CURATED_AI_BANK[0], id: 'ai-gen-' + Date.now() };
    return res.json(fallback);
  }
});

// Endpoint: AI Study Partner Chat
app.post('/api/gemini/mentor', async (req, res) => {
  try {
    const { message, activeQuestion } = req.body;
    if (!message) {
      return res.status(400).json({ error: 'Message is required' });
    }

    if (ai) {
      const context = activeQuestion
        ? `Active Question Context:\nTitle: ${activeQuestion.title}\nSection: ${activeQuestion.section} (${activeQuestion.exam})\nProblem: ${activeQuestion.text}\nCorrect Answer: ${activeQuestion.correctAnswer}\nOfficial Explanation: ${activeQuestion.explanation}`
        : 'General CAT Aptitude Mentorship.';

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: `Student question: "${message}"\nContext: ${context}\nGive a concise, high-rigor, Socratic shortcut explanation. Maximum 3-4 sentences. Zero fluff.`,
        config: {
          systemInstruction:
            'You are Aura, Zenith’s 99.9th-percentile CAT cognitive co-pilot. You explain problems through invariants, extremal bounds, modular residue cycles, and pigeonhole principles without spoon-feeding.',
        },
      });

      const reply = response.text;
      return res.json({ reply });
    }

    // Fallback response if no key
    return res.json({
      reply:
        'From a rigorous CAT perspective: Isolate the invariant. If dealing with exponents, check prime modulo residues (e.g. Fermat’s Little Theorem mod 7 or Euler’s Totient). If tackling DILR, map the tightest constraint first to eliminate branching. Would you like a step-by-step breakdown?',
    });
  } catch (err: any) {
    console.warn('Gemini chat error, falling back:', err.message);
    return res.json({
      reply:
        'Cognitive analysis: Focus on testing extremal values (0, 1, or maximum boundary conditions) to invalidate incorrect options instantly.',
    });
  }
});

// Setup dev server with Vite or production static serve
async function startServer() {
  // Serve static assets from public directory (manifest.json, sw.js, icons)
  app.use(express.static(path.resolve(__dirname, 'public')));

  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(port, () => {
    console.log(`Zenith Engine running on http://localhost:${port}`);
  });
}

startServer();
