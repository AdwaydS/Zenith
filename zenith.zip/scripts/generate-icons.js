import fs from 'fs';
import path from 'path';
import zlib from 'zlib';

// Function to generate an uncompressed PNG buffer using native Node zlib
function createZenithPNG(size) {
  const width = size;
  const height = size;

  // Raw uncompressed bitmap data: each row starts with a filter byte (0) followed by width * 4 (RGBA) bytes
  const rowLength = 1 + width * 4;
  const rawData = Buffer.alloc(rowLength * height);

  const bgR = 9;
  const bgG = 10;
  const bgB = 15; // #090a0f

  const center = size / 2;
  const maxBox = size * 0.44;
  const cornerRadius = size * 0.18;

  for (let y = 0; y < height; y++) {
    const rowOffset = y * rowLength;
    rawData[rowOffset] = 0; // Filter: None

    for (let x = 0; x < width; x++) {
      const pxOffset = rowOffset + 1 + x * 4;

      const dx = Math.abs(x - center);
      const dy = Math.abs(y - center);
      const distFromCenter = Math.sqrt((x - center) ** 2 + (y - center) ** 2);

      // Squircle / rounded container
      const isInsideCard =
        Math.max(dx, dy) <= maxBox - cornerRadius ||
        (dx > maxBox - cornerRadius &&
          dy > maxBox - cornerRadius &&
          Math.sqrt((dx - (maxBox - cornerRadius)) ** 2 + (dy - (maxBox - cornerRadius)) ** 2) <=
            cornerRadius);

      let r = bgR;
      let g = bgG;
      let b = bgB;
      let a = 255;

      if (isInsideCard) {
        // Subtle deep space radial ambient flare
        const flare = Math.max(0, 1 - distFromCenter / (size * 0.45));
        r = Math.floor(10 + 25 * flare);
        g = Math.floor(13 + 35 * flare);
        b = Math.floor(22 + 75 * flare);

        // Thin neon border
        const borderDist = maxBox - Math.max(dx, dy);
        if (borderDist >= 0 && borderDist <= size * 0.02) {
          r = 56;
          g = 189;
          b = 248; // Cyan glowing rim
        }

        // Orbital Ring check (ellipse tilted at ~25 deg)
        // Transform (x, y) by angle -25 deg
        const angle = -25 * (Math.PI / 180);
        const cosA = Math.cos(angle);
        const sinA = Math.sin(angle);
        const rotX = (x - center) * cosA - (y - center) * sinA;
        const rotY = (x - center) * sinA + (y - center) * cosA;
        const ellipseDist = Math.abs(Math.sqrt((rotX / (size * 0.35)) ** 2 + (rotY / (size * 0.15)) ** 2) - 1);
        if (ellipseDist < 0.04) {
          r = Math.min(255, r + 70);
          g = Math.min(255, g + 130);
          b = Math.min(255, b + 240);
        }

        // Diamond Guide outline
        const diamondDist = Math.abs(dx / (size * 0.32) + dy / (size * 0.38) - 1);
        if (diamondDist < 0.025) {
          r = Math.min(255, r + 45);
          g = Math.min(255, g + 90);
          b = Math.min(255, b + 180);
        }

        // Stylized 'Z' glyph
        const zLeft = center - size * 0.23;
        const zRight = center + size * 0.23;
        const zTop = center - size * 0.19;
        const zBottom = center + size * 0.23;
        const zThickness = size * 0.085;

        const inZTopBar = y >= zTop && y <= zTop + zThickness && x >= zLeft && x <= zRight;
        const inZBottomBar = y >= zBottom - zThickness && y <= zBottom && x >= zLeft && x <= zRight;

        // Diagonal power slash
        const diagProgress =
          (y - (zTop + zThickness * 0.5)) / (zBottom - zThickness * 0.5 - (zTop + zThickness * 0.5));
        const expectedX = zRight - diagProgress * (zRight - zLeft);
        const inZDiag =
          y >= zTop + zThickness * 0.4 &&
          y <= zBottom - zThickness * 0.4 &&
          Math.abs(x - expectedX) <= zThickness * 0.72;

        if (inZTopBar || inZBottomBar || inZDiag) {
          if (inZTopBar) {
            // Cyan-to-blue top
            r = 103;
            g = 232;
            b = 249;
          } else if (inZDiag) {
            // Iridescent white-blue-violet
            const t = Math.max(0, Math.min(1, diagProgress));
            r = Math.floor(255 * (1 - t * 0.4));
            g = Math.floor(220 * (1 - t * 0.45));
            b = Math.floor(255);
          } else {
            // Deep royal violet bottom plinth
            r = 139;
            g = 92;
            b = 246;
          }
        }

        // Zenith Apex Star at summit: center, y: center - size * 0.28
        const starX = center;
        const starY = center - size * 0.27;
        const sDistX = Math.abs(x - starX);
        const sDistY = Math.abs(y - starY);
        const starRay = (sDistX < size * 0.012 && sDistY < size * 0.075) || (sDistY < size * 0.012 && sDistX < size * 0.075);
        const starCore = Math.sqrt((x - starX) ** 2 + (y - starY) ** 2) <= size * 0.022;

        if (starRay || starCore) {
          r = 255;
          g = 255;
          b = 255;
        }

        // Center Prism Core
        const coreDist = Math.sqrt((x - center) ** 2 + (y - (center + size * 0.03)) ** 2);
        if (coreDist <= size * 0.028) {
          r = 255;
          g = 255;
          b = 255;
        }
      }

      rawData[pxOffset] = r;
      rawData[pxOffset + 1] = g;
      rawData[pxOffset + 2] = b;
      rawData[pxOffset + 3] = a;
    }
  }

  const compressedData = zlib.deflateSync(rawData);
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  const ihdrData = Buffer.alloc(13);
  ihdrData.writeUInt32BE(width, 0);
  ihdrData.writeUInt32BE(height, 4);
  ihdrData.writeUInt8(8, 8);
  ihdrData.writeUInt8(6, 9);
  ihdrData.writeUInt8(0, 10);
  ihdrData.writeUInt8(0, 11);
  ihdrData.writeUInt8(0, 12);
  const ihdrChunk = createChunk('IHDR', ihdrData);
  const idatChunk = createChunk('IDAT', compressedData);
  const iendChunk = createChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

function createChunk(type, data) {
  const length = data.length;
  const chunk = Buffer.alloc(12 + length);
  chunk.writeUInt32BE(length, 0);
  chunk.write(type, 4, 4, 'ascii');
  data.copy(chunk, 8);

  const crcTarget = Buffer.concat([Buffer.from(type, 'ascii'), data]);
  const crc = crc32(crcTarget);
  chunk.writeUInt32BE(crc, 8 + length);
  return chunk;
}

const crcTable = new Uint32Array(256);
for (let n = 0; n < 256; n++) {
  let c = n;
  for (let k = 0; k < 8; k++) {
    c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
  }
  crcTable[n] = c;
}

function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c = crcTable[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

const publicDir = path.resolve('public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

fs.writeFileSync(path.join(publicDir, 'icon-512.png'), createZenithPNG(512));
fs.writeFileSync(path.join(publicDir, 'zenith-logo.png'), createZenithPNG(512));
fs.writeFileSync(path.join(publicDir, 'icon-192.png'), createZenithPNG(192));
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), createZenithPNG(180));
console.log('Successfully generated new Zenith aesthetic PNG icons in public/');
