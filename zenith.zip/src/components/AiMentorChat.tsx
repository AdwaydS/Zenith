import React, { useState } from 'react';
import { Question, ChatMessage } from '../types.ts';
import { Send, Bot, User, Sparkles, HelpCircle } from 'lucide-react';

interface AiMentorChatProps {
  activeQuestion: Question;
}

export const AiMentorChat: React.FC<AiMentorChatProps> = ({ activeQuestion }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'init-1',
      sender: 'aura',
      text: "Greetings. I am your CAT-anchored cognitive co-pilot. Stuck on an extremal condition, modular residue cycle, or a subtle VARC assumption? Ask me for a shortcut or Socratic breakdown.",
      timestamp: 'Just now'
    }
  ]);
  const [input, setInput] = useState('');
  const [isThinking, setIsThinking] = useState(false);

  const sendMessage = async (overrideText?: string) => {
    const textToSend = overrideText || input;
    if (!textToSend.trim() || isThinking) return;

    const userMsg: ChatMessage = {
      id: 'user-' + Date.now(),
      sender: 'user',
      text: textToSend,
      timestamp: 'Now'
    };
    setMessages((prev) => [...prev, userMsg]);
    if (!overrideText) setInput('');
    setIsThinking(true);

    try {
      const response = await fetch('/api/gemini/mentor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: textToSend,
          activeQuestion
        })
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const data = await response.json();
      const aiMsg: ChatMessage = {
        id: 'aura-' + Date.now(),
        sender: 'aura',
        text: data.reply || 'Check the extremal boundary condition to isolate the invariant.',
        timestamp: 'Now'
      };
      setMessages((prev) => [...prev, aiMsg]);
    } catch (err: any) {
      console.warn('Ai mentor fetch error:', err);
      const fallbackMsg: ChatMessage = {
        id: 'aura-fb-' + Date.now(),
        sender: 'aura',
        text: 'Cognitive Shortcut: For powers like 3²⁰²⁴ mod 10, observe cycle length 4: 3¹=3, 3²=9, 3³=27≡7, 3⁴=81≡1. Since 2024 is divisible by 4, 3²⁰²⁴≡1 mod 10.',
        timestamp: 'Now'
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsThinking(false);
    }
  };

  const quickPrompts = [
    'What is the fundamental invariant?',
    'Give me a Socratic hint without the answer',
    'Explain the shortcut formula'
  ];

  return (
    <div className="flex flex-col h-[620px] rounded-xl border border-[#27272a] bg-[#121215] overflow-hidden">
      {/* Header */}
      <div className="p-3.5 border-b border-[#27272a] bg-zinc-900/60 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bot className="w-4 h-4 text-zinc-300" />
          <span className="font-semibold text-xs text-zinc-100">Aura Study Partner</span>
        </div>
        <span className="text-[10px] font-mono text-zinc-400">CAT Copilot</span>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 p-3.5 overflow-y-auto space-y-3 text-xs font-sans">
        {messages.map((m) => {
          const isUser = m.sender === 'user';
          return (
            <div
              key={m.id}
              className={`flex gap-2 ${isUser ? 'justify-end' : 'justify-start'}`}
            >
              {!isUser && (
                <div className="w-5 h-5 rounded bg-zinc-800 border border-zinc-700 flex items-center justify-center shrink-0 mt-0.5">
                  <Sparkles className="w-3 h-3 text-amber-300" />
                </div>
              )}
              <div
                className={`max-w-[85%] p-3 rounded-lg leading-relaxed ${
                  isUser
                    ? 'bg-zinc-200 text-zinc-950 font-medium'
                    : 'bg-[#09090b] border border-[#27272a] text-zinc-300'
                }`}
              >
                {m.text}
              </div>
            </div>
          );
        })}

        {isThinking && (
          <div className="flex gap-2 justify-start items-center">
            <div className="w-5 h-5 rounded bg-zinc-800 border border-zinc-700 flex items-center justify-center shrink-0">
              <Sparkles className="w-3 h-3 text-amber-300 animate-spin" />
            </div>
            <div className="p-2.5 rounded-lg bg-[#09090b] border border-[#27272a] text-zinc-400 font-mono text-[11px]">
              Analyzing problem invariants...
            </div>
          </div>
        )}
      </div>

      {/* Quick Prompt Chips */}
      <div className="p-2.5 border-t border-[#27272a] bg-[#09090b] flex flex-wrap gap-1.5">
        {quickPrompts.map((prompt, i) => (
          <button
            key={i}
            onClick={() => sendMessage(prompt)}
            disabled={isThinking}
            className="px-2 py-1 rounded bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-[10px] text-zinc-300 transition-colors disabled:opacity-50 text-left truncate max-w-[200px]"
          >
            {prompt}
          </button>
        ))}
      </div>

      {/* Input Box */}
      <div className="p-3 border-t border-[#27272a] bg-[#121215]">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            sendMessage();
          }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask shortcut, LR table rule, or proof..."
            className="flex-1 bg-[#09090b] border border-[#27272a] rounded-lg px-3 py-2 text-xs text-zinc-100 placeholder:text-zinc-500 focus:outline-none focus:border-zinc-500"
          />
          <button
            type="submit"
            disabled={isThinking || !input.trim()}
            className="p-2 bg-zinc-100 hover:bg-white text-zinc-950 rounded-lg transition-colors disabled:opacity-40"
            aria-label="Send message"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>
    </div>
  );
};
