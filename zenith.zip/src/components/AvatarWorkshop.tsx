import React, { useState } from 'react';
import { AvatarItem, UserProfile } from '../types.ts';
import { purchaseAvatarItem } from '../utils/engine-logic.ts';
import { Zap, Flame, Shield, Check, Award, Sparkles } from 'lucide-react';

interface AvatarWorkshopProps {
  user: UserProfile | null;
  auraPoints: number;
  setAuraPoints: React.Dispatch<React.SetStateAction<number>>;
  eloRating: number;
  streak: number;
  activeAvatarTitle: string;
  setActiveAvatarTitle: (title: string) => void;
  avatarItems: AvatarItem[];
  setAvatarItems: React.Dispatch<React.SetStateAction<AvatarItem[]>>;
}

export const AvatarWorkshop: React.FC<AvatarWorkshopProps> = ({
  user,
  auraPoints,
  setAuraPoints,
  eloRating,
  streak,
  activeAvatarTitle,
  setActiveAvatarTitle,
  avatarItems,
  setAvatarItems,
}) => {
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const handlePurchase = (item: AvatarItem) => {
    const outcome = purchaseAvatarItem(auraPoints, item.cost);
    if (outcome.success) {
      setAuraPoints(outcome.remainingAura);
      setAvatarItems((prev) =>
        prev.map((i) => (i.id === item.id ? { ...i, unlocked: true } : i))
      );
      setActiveAvatarTitle(item.name);
      setToastMessage(`Unlocked & equipped: ${item.name}!`);
      setTimeout(() => setToastMessage(null), 3000);
    } else {
      setToastMessage(outcome.message);
      setTimeout(() => setToastMessage(null), 3500);
    }
  };

  const handleEquip = (name: string) => {
    setActiveAvatarTitle(name);
    setToastMessage(`Equipped title: ${name}`);
    setTimeout(() => setToastMessage(null), 2500);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Page Title */}
      <div>
        <h1 className="text-lg font-bold text-zinc-100">RPG Character Builder & Aura Economy</h1>
        <p className="text-zinc-400 text-xs mt-1">
          Aura points are earned by solving CAT sets with mathematical precision and submitting open-source PRs.
        </p>
      </div>

      {/* Toast Notification */}
      {toastMessage && (
        <div className="p-3 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-zinc-200 flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-amber-300 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Character Dossier Card */}
      <div className="p-6 rounded-xl border border-[#27272a] bg-[#121215] flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-xl border-2 border-zinc-700 bg-[#09090b] flex items-center justify-center text-xl font-bold font-mono text-zinc-200 shadow-inner">
            {user ? user.name.charAt(0) : 'Z'}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-zinc-100">
                {user ? user.name : 'Anonymous Aspirant'}
              </h2>
              <span className="text-xs text-zinc-400 font-mono">
                · {user ? user.tier : 'Candidate'}
              </span>
            </div>
            <p className="text-xs text-blue-400 font-mono mt-0.5">{activeAvatarTitle}</p>
            <div className="flex items-center gap-1.5 text-xs text-zinc-400 mt-1.5">
              <Flame className="w-3.5 h-3.5 text-amber-400" />
              <span>Consecutive Practice Streak: {streak} Days</span>
            </div>
          </div>
        </div>

        {/* Telemetry Numbers */}
        <div className="flex items-center gap-6 sm:border-l sm:border-zinc-800 sm:pl-6 text-center">
          <div>
            <span className="block text-[11px] text-zinc-400 font-mono">Aura Balance</span>
            <div className="flex items-center justify-center gap-1 text-xl font-bold text-amber-300 font-mono tabular-nums">
              <Zap className="w-4 h-4 text-amber-400" />
              <span>{auraPoints}</span>
            </div>
          </div>
          <div>
            <span className="block text-[11px] text-zinc-400 font-mono">Elo Standing</span>
            <span className="text-xl font-bold text-zinc-100 font-mono tabular-nums block">
              {eloRating}
            </span>
          </div>
        </div>
      </div>

      {/* Augments Store */}
      <div className="space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-[#27272a]">
          <h3 className="text-xs font-semibold text-zinc-300 uppercase tracking-wider font-mono">
            Cognitive Augments & Accoutrements
          </h3>
          <span className="text-xs text-zinc-500 font-mono">{avatarItems.length} Available</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {avatarItems.map((item) => {
            const isEquipped = activeAvatarTitle === item.name;

            return (
              <div
                key={item.id}
                className="p-4 rounded-xl border border-[#27272a] bg-[#121215] flex flex-col justify-between space-y-3"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <p className="font-semibold text-sm text-zinc-100">{item.name}</p>
                    <span className="text-[10px] text-zinc-400 font-mono uppercase">
                      {item.type}
                    </span>
                  </div>
                  <p className="text-xs text-zinc-400 mt-1 leading-relaxed">
                    {item.description}
                  </p>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-zinc-800/60">
                  <span className="text-xs text-amber-300 font-mono font-medium">
                    {item.cost} Aura
                  </span>

                  {item.unlocked ? (
                    <button
                      onClick={() => handleEquip(item.name)}
                      className={`px-3 py-1 rounded-md text-xs font-medium transition-colors ${
                        isEquipped
                          ? 'bg-zinc-800 text-emerald-400 border border-emerald-800/60'
                          : 'border border-zinc-700 text-zinc-300 hover:bg-zinc-800'
                      }`}
                    >
                      {isEquipped ? 'Equipped' : 'Equip'}
                    </button>
                  ) : (
                    <button
                      onClick={() => handlePurchase(item)}
                      className="px-3 py-1 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-md text-xs font-medium transition-colors"
                    >
                      Unlock Augment
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
