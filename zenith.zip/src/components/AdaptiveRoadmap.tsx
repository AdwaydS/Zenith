import React, { useState, useEffect } from 'react';
import { RoadmapWeek, RoadmapDifficulty } from '../types.ts';
import { calculateCurriculumProgress, filterRoadmapByMonth } from '../utils/engine-logic.ts';
import {
  Check,
  Lock,
  Play,
  Layers,
  ChevronDown,
  ChevronUp,
  Calendar,
  Clock,
  Award,
  Sparkles,
  CheckCircle2,
} from 'lucide-react';

interface AdaptiveRoadmapProps {
  roadmap: RoadmapWeek[];
  onSelectPractice: (section?: string) => void;
  userElo: number;
  onAwardAura: (pts: number) => void;
}

export const AdaptiveRoadmap: React.FC<AdaptiveRoadmapProps> = ({
  roadmap,
  onSelectPractice,
  userElo,
  onAwardAura,
}) => {
  const [selectedMonth, setSelectedMonth] = useState<1 | 2 | 'all'>('all');
  const [expandedWeeks, setExpandedWeeks] = useState<Record<number, boolean>>({ 1: true, 3: true });

  // Completed days set saved in localStorage
  const [completedDays, setCompletedDays] = useState<number[]>(() => {
    try {
      const saved = localStorage.getItem('zenith_completed_days');
      return saved ? JSON.parse(saved) : [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]; // default 14 days (weeks 1 & 2 completed)
    } catch {
      return [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14];
    }
  });

  useEffect(() => {
    localStorage.setItem('zenith_completed_days', JSON.stringify(completedDays));
  }, [completedDays]);

  const toggleDay = (day: number) => {
    setCompletedDays((prev) => {
      const exists = prev.includes(day);
      if (exists) {
        return prev.filter((d) => d !== day);
      } else {
        onAwardAura(15);
        return [...prev, day].sort((a, b) => a - b);
      }
    });
  };

  const toggleWeekExpand = (weekId: number) => {
    setExpandedWeeks((prev) => ({
      ...prev,
      [weekId]: !prev[weekId],
    }));
  };

  const progress = calculateCurriculumProgress(completedDays.length, 60);
  const filteredWeeks = filterRoadmapByMonth(roadmap, selectedMonth);

  const getDifficultyBadge = (difficulty: RoadmapDifficulty) => {
    switch (difficulty) {
      case 'Easy':
        return 'text-emerald-400 bg-emerald-950/40 border-emerald-800/40';
      case 'Easy-Medium':
        return 'text-teal-400 bg-teal-950/40 border-teal-800/40';
      case 'Medium':
        return 'text-blue-400 bg-blue-950/40 border-blue-800/40';
      case 'Hard':
        return 'text-amber-400 bg-amber-950/40 border-amber-800/40';
      case 'Super Hard':
        return 'text-purple-400 bg-purple-950/40 border-purple-800/40';
      default:
        return 'text-zinc-400 bg-zinc-900 border-zinc-800';
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* 2-Month Master Curriculum Banner */}
      <div className="p-5 sm:p-6 rounded-xl border border-[#27272a] bg-[#121215] space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/30">
                60-Day Intensive
              </span>
              <span className="text-xs text-zinc-400 font-mono">
                Scratch (Easy) ➔ Apex Master (Super Hard)
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-zinc-100 mt-1">
              2-Month CAT & Aptitude Mastery Roadmap
            </h1>
            <p className="text-xs sm:text-sm text-zinc-400 mt-1 leading-relaxed">
              Designed by <strong className="text-zinc-200">Adwayd</strong>. From foundational Vedic arithmetic and elementary linear seating to non-linear Diophantine systems and 99.99th-percentile tournament matrices.
            </p>
          </div>

          <div className="sm:text-right shrink-0">
            <span className="text-xs text-zinc-400 font-mono block">Curriculum Progress</span>
            <div className="text-xl sm:text-2xl font-bold text-emerald-400 font-mono tabular-nums">
              {completedDays.length} / 60 <span className="text-xs text-zinc-500 font-normal">Days</span>
            </div>
            <span className="text-xs text-zinc-500 font-mono">{progress.percentage}% Complete</span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="space-y-1.5 pt-2 border-t border-zinc-800/80">
          <div className="flex justify-between text-xs font-mono text-zinc-400">
            <span>{progress.phase}</span>
            <span>{progress.remainingDays} Days Remaining</span>
          </div>
          <div className="w-full h-2 rounded-full bg-zinc-900 overflow-hidden border border-zinc-800">
            <div
              className="h-full bg-gradient-to-r from-emerald-500 via-blue-500 to-amber-500 transition-all duration-500 rounded-full"
              style={{ width: `${progress.percentage}%` }}
            />
          </div>
        </div>
      </div>

      {/* Month Filter Selector */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="flex items-center p-1 bg-zinc-900 rounded-lg border border-zinc-800 overflow-x-auto scrollbar-none">
          <button
            onClick={() => setSelectedMonth('all')}
            className={`px-3.5 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
              selectedMonth === 'all'
                ? 'bg-zinc-800 text-white shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            All 8 Weeks (Full 60 Days)
          </button>
          <button
            onClick={() => setSelectedMonth(1)}
            className={`px-3.5 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
              selectedMonth === 1
                ? 'bg-zinc-800 text-white shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Month 1: Ground Zero (Easy to Med)
          </button>
          <button
            onClick={() => setSelectedMonth(2)}
            className={`px-3.5 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
              selectedMonth === 2
                ? 'bg-zinc-800 text-white shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Month 2: Apex Mastery (Hard to Super Hard)
          </button>
        </div>

        <span className="text-xs text-zinc-400 font-mono text-center sm:text-right">
          +15 Aura per day checked
        </span>
      </div>

      {/* Weeks Stack */}
      <div className="space-y-4">
        {filteredWeeks.map((item) => {
          const isCompleted = item.status === 'completed';
          const isActive = item.status === 'active';
          const isLocked = item.status === 'locked';
          const isExpanded = !!expandedWeeks[item.id];

          // Count days completed in this week
          const weekDays = item.dailyMilestones.map((m) => m.day);
          const weekDaysCompleted = weekDays.filter((d) => completedDays.includes(d)).length;
          const weekPercent = Math.round((weekDaysCompleted / weekDays.length) * 100);

          return (
            <div
              key={item.id}
              className={`p-4 sm:p-5 rounded-xl border transition-all ${
                isActive
                  ? 'border-zinc-500 bg-zinc-900/40 shadow-sm'
                  : isCompleted
                  ? 'border-[#27272a] bg-[#121215]'
                  : 'border-zinc-800/50 bg-zinc-900/20'
              }`}
            >
              {/* Header row */}
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                <div className="flex items-start gap-3 sm:gap-4">
                  {/* Status Indicator */}
                  <div
                    className={`mt-0.5 w-7 h-7 sm:w-8 sm:h-8 rounded-lg flex items-center justify-center font-mono text-xs font-bold shrink-0 ${
                      isCompleted
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/60'
                        : isActive
                        ? 'bg-blue-950 text-blue-300 border border-blue-800/60'
                        : 'bg-zinc-800 text-zinc-500 border border-zinc-700/50'
                    }`}
                  >
                    {isCompleted ? (
                      <Check className="w-4 h-4" />
                    ) : isLocked ? (
                      <Lock className="w-3.5 h-3.5" />
                    ) : (
                      item.week
                    )}
                  </div>

                  {/* Level Details */}
                  <div className="space-y-2 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-zinc-100 text-sm sm:text-base">
                        Week {item.week}: {item.title}
                      </span>
                      <span
                        className={`text-[10px] font-mono px-2 py-0.5 rounded border ${getDifficultyBadge(
                          item.difficulty
                        )}`}
                      >
                        {item.difficulty}
                      </span>
                      <span className="text-[11px] text-zinc-400 font-mono">
                        ({item.dayRange})
                      </span>
                    </div>

                    <div className="flex items-center gap-3 text-xs text-zinc-400 flex-wrap">
                      <span className="text-zinc-300 font-medium">{item.tier}</span>
                      <span aria-hidden="true" className="text-zinc-600">·</span>
                      <span className="text-emerald-400 font-mono font-medium">
                        Target: {item.targetPercentile}
                      </span>
                      <span aria-hidden="true" className="text-zinc-600">·</span>
                      <span className="flex items-center gap-1 font-mono text-zinc-400">
                        <Clock className="w-3 h-3 text-zinc-500" />
                        {item.estimatedHours} hrs
                      </span>
                    </div>

                    {/* Topics Unboxed list */}
                    <div className="flex items-center gap-1.5 text-xs text-zinc-400 flex-wrap pt-1">
                      <span className="text-zinc-500 font-medium">Core Syllabus:</span>
                      {item.topics.map((t, idx) => (
                        <React.Fragment key={idx}>
                          <span className="text-zinc-300">{t}</span>
                          {idx < item.topics.length - 1 && (
                            <span aria-hidden="true" className="text-zinc-700">·</span>
                          )}
                        </React.Fragment>
                      ))}
                    </div>

                    {/* Spillover Exams */}
                    <div className="flex items-center gap-1.5 pt-1 flex-wrap">
                      <Layers className="w-3 h-3 text-zinc-500 shrink-0" />
                      <span className="text-[11px] text-zinc-500">Multiverse Spillover:</span>
                      {item.examSpillover.map((ex, i) => (
                        <span
                          key={i}
                          className="text-[10px] px-2 py-0.5 rounded bg-zinc-900 border border-zinc-800 text-zinc-300 font-mono"
                        >
                          {ex}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Right Threshold & Actions */}
                <div className="flex sm:flex-col items-center sm:items-end justify-between sm:justify-start gap-2 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-zinc-800/60">
                  <div className="text-left sm:text-right">
                    <span className="text-zinc-500 block text-[11px] font-mono">
                      Completion
                    </span>
                    <span className="text-zinc-200 font-mono text-xs font-semibold">
                      {weekDaysCompleted} / {weekDays.length} Days ({weekPercent}%)
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onSelectPractice(item.week <= 4 ? 'Quant' : 'DILR')}
                      className="px-3 py-1.5 bg-zinc-100 hover:bg-white text-zinc-950 font-semibold rounded-lg text-xs transition-colors flex items-center gap-1 min-h-[34px]"
                    >
                      <Play className="w-3 h-3 fill-current" />
                      <span>Practice Week</span>
                    </button>
                    <button
                      onClick={() => toggleWeekExpand(item.id)}
                      className="p-1.5 text-zinc-400 hover:text-zinc-200 border border-zinc-800 rounded-lg transition-colors"
                      aria-label="Toggle weekly details"
                    >
                      {isExpanded ? (
                        <ChevronUp className="w-4 h-4" />
                      ) : (
                        <ChevronDown className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>
              </div>

              {/* Collapsible Daily Milestones Breakdown (Day 1 to 7 for each week) */}
              {isExpanded && (
                <div className="mt-4 pt-4 border-t border-zinc-800/80 space-y-2">
                  <div className="flex items-center justify-between text-xs font-mono text-zinc-400 pb-1">
                    <span className="font-semibold text-zinc-300">
                      Day-by-Day Milestone Roadmap
                    </span>
                    <span>Click day checkbox to log completion (+15 Aura)</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                    {item.dailyMilestones.map((m) => {
                      const isDone = completedDays.includes(m.day);
                      return (
                        <div
                          key={m.day}
                          onClick={() => toggleDay(m.day)}
                          className={`flex items-start gap-2.5 p-2.5 rounded-lg border cursor-pointer transition-all ${
                            isDone
                              ? 'border-emerald-500/30 bg-emerald-950/10 text-zinc-200'
                              : 'border-zinc-800 bg-[#09090b] hover:border-zinc-700 text-zinc-400'
                          }`}
                        >
                          <div
                            className={`w-4 h-4 rounded border mt-0.5 flex items-center justify-center shrink-0 ${
                              isDone
                                ? 'bg-emerald-500 border-emerald-500 text-zinc-950'
                                : 'border-zinc-600'
                            }`}
                          >
                            {isDone && <Check className="w-3 h-3 stroke-[3]" />}
                          </div>
                          <div className="text-xs">
                            <div className="flex items-center gap-1.5 font-mono text-[10px]">
                              <span className="font-semibold text-zinc-300">Day {m.day}</span>
                              <span className="text-zinc-600">·</span>
                              <span className="text-zinc-400">{m.focus}</span>
                              <span className="text-zinc-600">·</span>
                              <span
                                className={`px-1.5 py-0.2 rounded text-[9px] ${
                                  m.type === 'Concept'
                                    ? 'bg-blue-950/50 text-blue-300'
                                    : m.type === 'Sandbox'
                                    ? 'bg-purple-950/50 text-purple-300'
                                    : m.type === 'Mock'
                                    ? 'bg-amber-950/50 text-amber-300'
                                    : 'bg-zinc-800 text-zinc-300'
                                }`}
                              >
                                {m.type}
                              </span>
                            </div>
                            <p className="text-zinc-200 text-xs mt-0.5 leading-snug">
                              {m.title}
                            </p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
