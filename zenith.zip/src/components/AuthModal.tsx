import React, { useState, useEffect, useRef } from 'react';
import { UserProfile } from '../types.ts';
import {
  auth,
  googleProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPhoneNumber,
  RecaptchaVerifier,
  sendPasswordResetEmail,
  updateProfile,
  ConfirmationResult,
} from '../lib/firebase.ts';
import {
  KeyRound,
  Mail,
  Phone,
  Sparkles,
  Lock,
  User,
  Eye,
  EyeOff,
  AlertCircle,
  CheckCircle2,
  ArrowRight,
  Loader2,
  RotateCcw,
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (user: UserProfile) => void;
}

const COUNTRY_CODES = [
  { code: '+91', country: 'IN', label: 'India (+91)' },
  { code: '+1', country: 'US', label: 'USA / Canada (+1)' },
  { code: '+44', country: 'UK', label: 'UK (+44)' },
  { code: '+971', country: 'AE', label: 'UAE (+971)' },
  { code: '+65', country: 'SG', label: 'Singapore (+65)' },
  { code: '+61', country: 'AU', label: 'Australia (+61)' },
  { code: '+49', country: 'DE', label: 'Germany (+49)' },
];

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const [authTab, setAuthTab] = useState<'otp' | 'email' | 'google'>('otp');
  
  // Phone OTP States
  const [countryCode, setCountryCode] = useState('+91');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [confirmationResult, setConfirmationResult] = useState<ConfirmationResult | null>(null);
  const [resendCooldown, setResendCooldown] = useState(0);

  // Email / Password States
  const [emailMode, setEmailMode] = useState<'signin' | 'signup' | 'forgot'>('signin');
  const [displayName, setDisplayName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [resetSent, setResetSent] = useState(false);

  // Status & Feedback States
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const recaptchaVerifierRef = useRef<RecaptchaVerifier | null>(null);

  // Timer for OTP resend cooldown
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (resendCooldown > 0) {
      timer = setTimeout(() => setResendCooldown((prev) => prev - 1), 1000);
    }
    return () => clearTimeout(timer);
  }, [resendCooldown]);

  // Clean up recaptcha on modal close or unmount
  useEffect(() => {
    return () => {
      if (recaptchaVerifierRef.current) {
        try {
          recaptchaVerifierRef.current.clear();
        } catch {
          // ignore
        }
        recaptchaVerifierRef.current = null;
      }
    };
  }, [isOpen]);

  if (!isOpen) return null;

  // Initialize invisible reCAPTCHA
  const setupRecaptcha = (): RecaptchaVerifier => {
    if (recaptchaVerifierRef.current) {
      try {
        recaptchaVerifierRef.current.clear();
      } catch {
        // ignore
      }
    }
    const verifier = new RecaptchaVerifier(auth, 'recaptcha-container', {
      size: 'invisible',
      callback: () => {
        // reCAPTCHA solved
      },
      'expired-callback': () => {
        setErrorMsg('reCAPTCHA expired. Please request OTP again.');
      },
    });
    recaptchaVerifierRef.current = verifier;
    return verifier;
  };

  // Helper to format clean error message
  const parseFirebaseError = (error: any): string => {
    const code = error?.code || '';
    switch (code) {
      case 'auth/invalid-phone-number':
        return 'Invalid phone number format. Please check country code and digits.';
      case 'auth/missing-phone-number':
        return 'Please enter a valid phone number.';
      case 'auth/quota-exceeded':
        return 'SMS quota exceeded for today. Please use Gmail ID / Password sign-in.';
      case 'auth/too-many-requests':
        return 'Too many attempts. Please wait a moment and try again.';
      case 'auth/code-expired':
        return 'SMS verification code has expired. Please request a new OTP.';
      case 'auth/invalid-verification-code':
        return 'Invalid OTP code. Please enter the exact 6 digits sent to your phone.';
      case 'auth/invalid-email':
        return 'Please enter a valid Gmail or email address.';
      case 'auth/user-not-found':
        return 'No Zenith account found for this email. Click "Create Account" below.';
      case 'auth/wrong-password':
      case 'auth/invalid-credential':
        return 'Incorrect email or password. Please verify and try again.';
      case 'auth/email-already-in-use':
        return 'An account already exists with this email. Please switch to Sign In.';
      case 'auth/weak-password':
        return 'Password must be at least 6 characters long.';
      case 'auth/popup-closed-by-user':
        return 'Google sign-in popup was closed before completing.';
      case 'auth/cancelled-popup-request':
        return 'Sign-in cancelled.';
      case 'auth/network-request-failed':
        return 'Network connection issue. Please check your internet connection.';
      default:
        return error?.message || 'Authentication error occurred. Please try again.';
    }
  };

  // 1. Send Real SMS OTP to Phone Number
  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    const cleanDigits = phoneNumber.replace(/[^0-9]/g, '');
    if (cleanDigits.length < 8) {
      setErrorMsg('Please enter a valid mobile number with at least 8 digits.');
      return;
    }

    const fullPhoneNumber = `${countryCode}${cleanDigits}`;

    setIsLoading(true);
    try {
      const appVerifier = setupRecaptcha();
      const confirmation = await signInWithPhoneNumber(auth, fullPhoneNumber, appVerifier);
      setConfirmationResult(confirmation);
      setOtpSent(true);
      setResendCooldown(45);
      setSuccessMsg(`Real OTP sent to ${fullPhoneNumber}. Check your SMS messages.`);
    } catch (err: any) {
      console.error('Phone OTP error:', err);
      setErrorMsg(parseFirebaseError(err));
      if (recaptchaVerifierRef.current) {
        try {
          recaptchaVerifierRef.current.clear();
        } catch {}
        recaptchaVerifierRef.current = null;
      }
    } finally {
      setIsLoading(false);
    }
  };

  // 2. Verify Phone SMS OTP
  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!confirmationResult) {
      setErrorMsg('Please request an OTP first.');
      return;
    }

    const cleanCode = otpCode.trim();
    if (cleanCode.length !== 6) {
      setErrorMsg('Please enter the 6-digit SMS verification code.');
      return;
    }

    setIsLoading(true);
    setErrorMsg('');
    try {
      const userCredential = await confirmationResult.confirm(cleanCode);
      const fbUser = userCredential.user;
      
      const phoneEnd = fbUser.phoneNumber ? fbUser.phoneNumber.slice(-4) : 'User';
      const profile: UserProfile = {
        uid: fbUser.uid,
        name: fbUser.displayName || `Scholar #${phoneEnd}`,
        email: fbUser.email,
        phoneNumber: fbUser.phoneNumber,
        avatar: fbUser.photoURL || null,
        tier: 'CAT / Multiverse Aspirant',
        provider: 'phone',
      };

      onSuccess(profile);
      onClose();
    } catch (err: any) {
      console.error('OTP confirmation error:', err);
      setErrorMsg(parseFirebaseError(err));
    } finally {
      setIsLoading(false);
    }
  };

  // 3. Email & Password Authentication (Sign In & Sign Up)
  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!email.trim() || !password.trim()) {
      setErrorMsg('Please enter both email and password.');
      return;
    }

    setIsLoading(true);
    try {
      if (emailMode === 'signup') {
        const userCredential = await createUserWithEmailAndPassword(auth, email.trim(), password);
        const fbUser = userCredential.user;
        const finalName = displayName.trim() || email.split('@')[0];

        if (finalName) {
          await updateProfile(fbUser, { displayName: finalName });
        }

        const profile: UserProfile = {
          uid: fbUser.uid,
          name: finalName,
          email: fbUser.email,
          phoneNumber: fbUser.phoneNumber,
          avatar: fbUser.photoURL || null,
          tier: 'CAT / Multiverse Scholar',
          provider: 'password',
        };

        onSuccess(profile);
        onClose();
      } else {
        const userCredential = await signInWithEmailAndPassword(auth, email.trim(), password);
        const fbUser = userCredential.user;

        const profile: UserProfile = {
          uid: fbUser.uid,
          name: fbUser.displayName || email.split('@')[0],
          email: fbUser.email,
          phoneNumber: fbUser.phoneNumber,
          avatar: fbUser.photoURL || null,
          tier: 'CAT / Multiverse Aspirant',
          provider: 'password',
        };

        onSuccess(profile);
        onClose();
      }
    } catch (err: any) {
      console.error('Email auth error:', err);
      setErrorMsg(parseFirebaseError(err));
    } finally {
      setIsLoading(false);
    }
  };

  // 4. Forgot Password Reset Email
  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !email.includes('@')) {
      setErrorMsg('Please enter your valid Gmail / email address to receive password reset link.');
      return;
    }

    setIsLoading(true);
    setErrorMsg('');
    try {
      await sendPasswordResetEmail(auth, email.trim());
      setResetSent(true);
      setSuccessMsg(`Password reset link sent to ${email.trim()}. Check your inbox.`);
    } catch (err: any) {
      console.error('Password reset error:', err);
      setErrorMsg(parseFirebaseError(err));
    } finally {
      setIsLoading(false);
    }
  };

  // 5. Real Google OAuth Popup Sign-In
  const handleGoogleLogin = async () => {
    setErrorMsg('');
    setSuccessMsg('');
    setIsLoading(true);
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const fbUser = result.user;

      const profile: UserProfile = {
        uid: fbUser.uid,
        name: fbUser.displayName || fbUser.email?.split('@')[0] || 'Zenith Scholar',
        email: fbUser.email,
        phoneNumber: fbUser.phoneNumber,
        avatar: fbUser.photoURL || null,
        tier: 'IIM-C Top 0.1% Track',
        provider: 'google',
      };

      onSuccess(profile);
      onClose();
    } catch (err: any) {
      console.error('Google Sign-In error:', err);
      setErrorMsg(parseFirebaseError(err));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      {/* Invisible reCAPTCHA container for Phone Auth */}
      <div id="recaptcha-container"></div>

      <div className="w-full max-w-md rounded-2xl border border-zinc-800 bg-[#121215] shadow-2xl p-5 sm:p-6 space-y-4 my-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-zinc-800/80 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-zinc-100 font-sans tracking-tight">
                Authentication & Sync
              </h3>
              <p className="text-[11px] text-zinc-400">Zenith Exam Prep & Aura Engine</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-zinc-500 hover:text-zinc-200 text-sm p-1.5 rounded-lg hover:bg-zinc-800/60 transition-colors"
            aria-label="Close"
          >
            ✕
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="grid grid-cols-3 gap-1 bg-zinc-900/80 p-1 rounded-xl border border-zinc-800/80 text-[11px] sm:text-xs">
          <button
            onClick={() => {
              setAuthTab('otp');
              setErrorMsg('');
              setSuccessMsg('');
            }}
            className={`py-1.5 sm:py-2 px-1 text-center font-medium rounded-lg transition-all flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-1.5 ${
              authTab === 'otp'
                ? 'bg-zinc-800 text-white shadow-sm border border-zinc-700/60'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Phone className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">Mobile OTP</span>
          </button>

          <button
            onClick={() => {
              setAuthTab('email');
              setErrorMsg('');
              setSuccessMsg('');
            }}
            className={`py-1.5 sm:py-2 px-1 text-center font-medium rounded-lg transition-all flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-1.5 ${
              authTab === 'email'
                ? 'bg-zinc-800 text-white shadow-sm border border-zinc-700/60'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Mail className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">Gmail / Pass</span>
          </button>

          <button
            onClick={() => {
              setAuthTab('google');
              setErrorMsg('');
              setSuccessMsg('');
            }}
            className={`py-1.5 sm:py-2 px-1 text-center font-medium rounded-lg transition-all flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-1.5 ${
              authTab === 'google'
                ? 'bg-zinc-800 text-white shadow-sm border border-zinc-700/60'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <svg className="w-3.5 h-3.5 shrink-0" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
              />
            </svg>
            <span className="truncate">Google</span>
          </button>
        </div>

        {/* Feedback Alerts */}
        {errorMsg && (
          <div className="flex items-start gap-2 p-2.5 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
            <span className="leading-snug">{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="flex items-start gap-2 p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs">
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
            <span className="leading-snug">{successMsg}</span>
          </div>
        )}

        {/* TAB 1: PHONE REAL SMS OTP */}
        {authTab === 'otp' && (
          <div className="space-y-3 pt-1">
            {!otpSent ? (
              <form onSubmit={handleSendOtp} className="space-y-3.5">
                <div>
                  <label className="block text-[11px] font-medium text-zinc-300 mb-1.5 font-mono">
                    Enter Mobile Number for Real SMS OTP
                  </label>
                  <div className="flex gap-2">
                    {/* Country Code Select */}
                    <select
                      value={countryCode}
                      onChange={(e) => setCountryCode(e.target.value)}
                      className="bg-[#09090b] border border-zinc-800 rounded-lg px-2.5 py-2 text-xs text-white focus:outline-none focus:border-zinc-500 shrink-0 font-mono"
                    >
                      {COUNTRY_CODES.map((item) => (
                        <option key={item.code} value={item.code} className="bg-zinc-900 text-white">
                          {item.country} ({item.code})
                        </option>
                      ))}
                    </select>

                    {/* Phone Number Input */}
                    <div className="relative flex-1">
                      <input
                        type="tel"
                        required
                        autoFocus
                        placeholder="9876543210"
                        value={phoneNumber}
                        onChange={(e) => setPhoneNumber(e.target.value)}
                        className="w-full bg-[#09090b] border border-zinc-800 rounded-lg px-3 py-2 text-xs text-white placeholder:text-zinc-600 focus:outline-none focus:border-zinc-500 font-mono tracking-wide"
                      />
                    </div>
                  </div>
                  <p className="text-[10px] text-zinc-500 mt-1.5">
                    A real 6-digit SMS verification code will be dispatched to this number.
                  </p>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-2.5 bg-white hover:bg-zinc-200 text-zinc-950 font-semibold rounded-lg text-xs transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Sending Real OTP...</span>
                    </>
                  ) : (
                    <>
                      <span>Send Real Verification Code</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>
              </form>
            ) : (
              <form onSubmit={handleVerifyOtp} className="space-y-3.5">
                <div>
                  <div className="flex justify-between items-center mb-1.5">
                    <label className="block text-[11px] font-medium text-zinc-300 font-mono">
                      Enter 6-Digit SMS Code
                    </label>
                    <span className="text-[11px] text-zinc-400 font-mono">
                      {countryCode} {phoneNumber}
                    </span>
                  </div>
                  <input
                    type="text"
                    inputMode="numeric"
                    maxLength={6}
                    autoFocus
                    placeholder="••••••"
                    value={otpCode}
                    onChange={(e) => setOtpCode(e.target.value.replace(/[^0-9]/g, ''))}
                    className="w-full text-center tracking-[0.5em] font-mono text-lg bg-[#09090b] border border-zinc-700 rounded-lg px-3 py-2.5 text-white focus:outline-none focus:border-zinc-400 shadow-inner"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isLoading || otpCode.length !== 6}
                  className="w-full py-2.5 bg-white hover:bg-zinc-200 text-zinc-950 font-semibold rounded-lg text-xs transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Verifying Code...</span>
                    </>
                  ) : (
                    <>
                      <span>Verify & Enter Zenith</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>

                <div className="flex items-center justify-between pt-1 text-[11px]">
                  <button
                    type="button"
                    onClick={() => {
                      setOtpSent(false);
                      setOtpCode('');
                      setErrorMsg('');
                    }}
                    className="text-zinc-400 hover:text-zinc-200 transition-colors underline underline-offset-4"
                  >
                    Change Number
                  </button>

                  <button
                    type="button"
                    disabled={resendCooldown > 0 || isLoading}
                    onClick={handleSendOtp}
                    className="text-blue-400 hover:text-blue-300 disabled:text-zinc-600 transition-colors flex items-center gap-1 font-mono"
                  >
                    <RotateCcw className="w-3 h-3" />
                    {resendCooldown > 0 ? `Resend in ${resendCooldown}s` : 'Resend SMS'}
                  </button>
                </div>
              </form>
            )}
          </div>
        )}

        {/* TAB 2: REAL GMAIL ID / EMAIL & PASSWORD */}
        {authTab === 'email' && (
          <div className="space-y-3 pt-1">
            {emailMode !== 'forgot' ? (
              <form onSubmit={handleEmailAuth} className="space-y-3">
                {emailMode === 'signup' && (
                  <div>
                    <label className="block text-[11px] font-medium text-zinc-400 mb-1 font-mono">
                      Your Full Name
                    </label>
                    <div className="relative">
                      <User className="w-3.5 h-3.5 absolute left-3 top-2.5 text-zinc-500" />
                      <input
                        type="text"
                        required
                        placeholder="e.g. Adwayd / Scholar"
                        value={displayName}
                        onChange={(e) => setDisplayName(e.target.value)}
                        className="w-full bg-[#09090b] border border-zinc-800 rounded-lg pl-9 pr-3 py-2 text-xs text-white placeholder:text-zinc-600 focus:outline-none focus:border-zinc-500"
                      />
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-[11px] font-medium text-zinc-400 mb-1 font-mono">
                    Gmail / Email Address
                  </label>
                  <div className="relative">
                    <Mail className="w-3.5 h-3.5 absolute left-3 top-2.5 text-zinc-500" />
                    <input
                      type="email"
                      required
                      placeholder="yourname@gmail.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-[#09090b] border border-zinc-800 rounded-lg pl-9 pr-3 py-2 text-xs text-white placeholder:text-zinc-600 focus:outline-none focus:border-zinc-500 font-mono"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="block text-[11px] font-medium text-zinc-400 font-mono">
                      Password
                    </label>
                    {emailMode === 'signin' && (
                      <button
                        type="button"
                        onClick={() => {
                          setEmailMode('forgot');
                          setErrorMsg('');
                          setSuccessMsg('');
                        }}
                        className="text-[10px] text-zinc-400 hover:text-zinc-200 transition-colors"
                      >
                        Forgot?
                      </button>
                    )}
                  </div>
                  <div className="relative">
                    <Lock className="w-3.5 h-3.5 absolute left-3 top-2.5 text-zinc-500" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      placeholder="Minimum 6 characters"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full bg-[#09090b] border border-zinc-800 rounded-lg pl-9 pr-9 py-2 text-xs text-white placeholder:text-zinc-600 focus:outline-none focus:border-zinc-500 font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-2.5 text-zinc-500 hover:text-zinc-300"
                    >
                      {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-2.5 bg-white hover:bg-zinc-200 text-zinc-950 font-semibold rounded-lg text-xs transition-colors flex items-center justify-center gap-2 disabled:opacity-50 mt-1"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>{emailMode === 'signup' ? 'Creating Account...' : 'Authenticating...'}</span>
                    </>
                  ) : (
                    <>
                      <span>{emailMode === 'signup' ? 'Create Zenith Account' : 'Sign In with Email'}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>

                {/* Switch between Sign In and Sign Up */}
                <div className="pt-2 text-center text-xs text-zinc-400 border-t border-zinc-800/60">
                  {emailMode === 'signin' ? (
                    <p>
                      New to Zenith?{' '}
                      <button
                        type="button"
                        onClick={() => {
                          setEmailMode('signup');
                          setErrorMsg('');
                          setSuccessMsg('');
                        }}
                        className="text-blue-400 hover:text-blue-300 font-medium underline underline-offset-4 ml-1"
                      >
                        Create an account
                      </button>
                    </p>
                  ) : (
                    <p>
                      Already have an account?{' '}
                      <button
                        type="button"
                        onClick={() => {
                          setEmailMode('signin');
                          setErrorMsg('');
                          setSuccessMsg('');
                        }}
                        className="text-blue-400 hover:text-blue-300 font-medium underline underline-offset-4 ml-1"
                      >
                        Sign In
                      </button>
                    </p>
                  )}
                </div>
              </form>
            ) : (
              <form onSubmit={handleForgotPassword} className="space-y-3">
                <p className="text-xs text-zinc-400 leading-relaxed">
                  Enter your Gmail / registered email address. We'll send you a password reset link.
                </p>
                <div>
                  <label className="block text-[11px] font-medium text-zinc-400 mb-1 font-mono">
                    Gmail / Email Address
                  </label>
                  <div className="relative">
                    <Mail className="w-3.5 h-3.5 absolute left-3 top-2.5 text-zinc-500" />
                    <input
                      type="email"
                      required
                      autoFocus
                      placeholder="adwayd91@gmail.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-[#09090b] border border-zinc-800 rounded-lg pl-9 pr-3 py-2 text-xs text-white placeholder:text-zinc-600 focus:outline-none focus:border-zinc-500 font-mono"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-2.5 bg-white hover:bg-zinc-200 text-zinc-950 font-semibold rounded-lg text-xs transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Sending Reset Link...</span>
                    </>
                  ) : (
                    <span>Send Password Reset Email</span>
                  )}
                </button>

                <div className="pt-2 text-center text-xs">
                  <button
                    type="button"
                    onClick={() => {
                      setEmailMode('signin');
                      setErrorMsg('');
                      setSuccessMsg('');
                    }}
                    className="text-zinc-400 hover:text-zinc-200 underline underline-offset-4"
                  >
                    Back to Sign In
                  </button>
                </div>
              </form>
            )}
          </div>
        )}

        {/* TAB 3: REAL GOOGLE POPUP AUTH */}
        {authTab === 'google' && (
          <div className="pt-2 space-y-4">
            <p className="text-xs text-zinc-400 leading-relaxed">
              Authenticate directly with your official Google account to synchronize CAT aptitude milestones, Elo ratings, and Avatar items securely with Firebase.
            </p>

            <button
              onClick={handleGoogleLogin}
              disabled={isLoading}
              className="w-full py-3 bg-zinc-900 hover:bg-zinc-800 text-zinc-100 border border-zinc-700/80 rounded-xl text-xs font-semibold flex items-center justify-center gap-3 transition-all hover:border-zinc-500 shadow-md disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-zinc-400" />
                  <span>Connecting with Google...</span>
                </>
              ) : (
                <>
                  <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                    />
                  </svg>
                  <span>Continue with Google Account</span>
                </>
              )}
            </button>

            <div className="text-[11px] text-zinc-500 bg-zinc-900/50 p-2.5 rounded-lg border border-zinc-800/80">
              <span className="text-zinc-300 font-medium">Auto-Sync Enabled:</span> Your progress and Aura points will be persisted securely in your cloud profile.
            </div>
          </div>
        )}

        {/* Security Footer */}
        <div className="pt-2 border-t border-zinc-800/60 flex items-center justify-between text-[10px] text-zinc-500">
          <span className="font-mono">Secured by Firebase Auth</span>
          <span>Zenith Open Source v2.1</span>
        </div>
      </div>
    </div>
  );
};
