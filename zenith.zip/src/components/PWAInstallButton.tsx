import React, { useState } from 'react';
import { createPortal } from 'react-dom';
import { Download, CheckCircle, Share, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall.ts';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, installApp, hasDeferredPrompt } = usePWAInstall();
  const [showGuideModal, setShowGuideModal] = useState(false);

  // If already running inside standalone app, show subtle indicator or nothing
  if (isInstalled) {
    return (
      <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-md border border-emerald-500/20 bg-emerald-500/5 text-emerald-400 font-mono text-xs">
        <CheckCircle className="w-3.5 h-3.5" />
        <span className="font-medium text-[11px]">Installed</span>
      </div>
    );
  }

  const handleInstallClick = async () => {
    if (hasDeferredPrompt) {
      await installApp();
    } else {
      setShowGuideModal(true);
    }
  };

  return (
    <>
      <button
        onClick={handleInstallClick}
        title="Install Zenith Exam Arena App"
        aria-label="Install Zenith Exam Arena App"
        className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-md border border-zinc-700 bg-zinc-900/90 hover:bg-zinc-800 text-zinc-200 hover:text-white transition-all text-xs font-medium cursor-pointer shadow-sm group"
      >
        <Download className="w-3.5 h-3.5 text-blue-400 group-hover:scale-110 transition-transform" />
        <span className="hidden xs:inline">Install App</span>
      </button>

      {/* Manual Installation Guide Modal for iOS or browsers without native prompt */}
      {showGuideModal && typeof document !== 'undefined' && createPortal(
        <div 
          className="fixed inset-0 z-[9999] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6"
          onClick={() => setShowGuideModal(false)}
        >
          <div 
            className="bg-[#121215] border border-zinc-800 rounded-xl p-5 sm:p-6 max-w-sm w-full shadow-2xl relative my-auto animate-in fade-in zoom-in-95 duration-150"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setShowGuideModal(false)}
              className="absolute top-4 right-4 text-zinc-400 hover:text-zinc-200 p-1 rounded-md hover:bg-zinc-800/60 transition-colors"
              aria-label="Close guide"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-zinc-900 border border-zinc-700 flex items-center justify-center p-1.5 shadow-md">
                <img src="/zenith-logo.svg" alt="Zenith Logo" referrerPolicy="no-referrer" className="w-full h-full object-contain" />
              </div>
              <div>
                <h3 className="font-semibold text-zinc-100 text-sm">Zenith Exam Arena</h3>
                <p className="text-xs text-zinc-400">Install as Standalone Web App</p>
              </div>
            </div>

            <p className="text-xs text-zinc-300 leading-relaxed mb-4">
              Install Zenith directly to your device for instant offline access, fullscreen aptitude practice, and rapid load speeds.
            </p>

            <div className="space-y-2.5 text-xs text-zinc-300 bg-zinc-950/60 p-3 rounded-lg border border-zinc-800/80 mb-4">
              <div className="flex items-start gap-2">
                <span className="font-mono text-blue-400 font-bold shrink-0">1.</span>
                <span>
                  <strong>On iPhone / iPad:</strong> Tap the <Share className="inline w-3.5 h-3.5 text-zinc-300 mx-0.5" /> <em>Share</em> button in Safari, then scroll and select <strong>"Add to Home Screen"</strong>.
                </span>
              </div>
              <div className="flex items-start gap-2">
                <span className="font-mono text-blue-400 font-bold shrink-0">2.</span>
                <span>
                  <strong>On Chrome / Edge:</strong> Click the install icon in the address bar or open the browser menu and select <strong>"Install Zenith Exam Arena"</strong>.
                </span>
              </div>
            </div>

            <button
              onClick={() => setShowGuideModal(false)}
              className="w-full py-2 bg-zinc-100 hover:bg-white text-zinc-950 font-semibold text-xs rounded-md transition-colors"
            >
              Got it
            </button>
          </div>
        </div>,
        document.body
      )}
    </>
  );
};
