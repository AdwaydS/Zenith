import React, { useState } from 'react';
import { Question } from '../types.ts';
import { Sparkles, CheckCircle2, XCircle, ArrowRight, Layers, RefreshCw } from 'lucide-react';

interface AptitudeArenaProps {
  questions: Question[];
  activeIdx: number;
  setActiveIdx: (idx: number) => void;
  selectedSection: string;
  setSelectedSection: (sec: string) => void;
  onAnswerSubmit: (isCorrect: boolean) => void;
  onGenerateQuestion: (section: string) => Promise<void>;
  isGeneratingAI: boolean;
}

export const AptitudeArena: React.FC<AptitudeArenaProps> = ({
  questions,
  activeIdx,
  setActiveIdx,
  selectedSection,
  setSelectedSection,
  onAnswerSubmit,
  onGenerateQuestion,
  isGeneratingAI,
}) => {
  const [userAnswer, setUserAnswer] = useState('');
  const [feedback, setFeedback] = useState<{
    status: 'correct' | 'incorrect';
    msg: string;
  } | null>(null);

  const currentQ = questions[activeIdx] || questions[0];

  const handleVerify = () => {
    if (!userAnswer.trim()) return;
    const isCorrect =
      userAnswer.trim().toLowerCase() === currentQ.correctAnswer.trim().toLowerCase();

    if (isCorrect) {
      setFeedback({
        status: 'correct',
        msg: 'Precise! 99th-percentile invariant executed.',
      });
      onAnswerSubmit(true);
    } else {
      setFeedback({
        status: 'incorrect',
        msg: `Incorrect. Expected value: ${currentQ.correctAnswer}`,
      });
      onAnswerSubmit(false);
    }
  };

  const handleNext = () => {
    const nextIdx = (activeIdx + 1) % questions.length;
    setActiveIdx(nextIdx);
    setUserAnswer('');
    setFeedback(null);
  };

  return (
    <div className="space-y-4 sm:space-y-5">
      {/* Filter Bar & AI Action - Fully Responsive */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 pb-2 border-b border-[#27272a]">
        <div className="flex items-center gap-1 p-1 bg-zinc-900 rounded-lg border border-zinc-800 overflow-x-auto scrollbar-none">
          {['All', 'Quant', 'DILR', 'VARC'].map((tab) => (
            <button
              key={tab}
              onClick={() => {
                setSelectedSection(tab);
                setActiveIdx(0);
                setUserAnswer('');
                setFeedback(null);
              }}
              className={`flex-1 sm:flex-initial px-3 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap min-h-[36px] sm:min-h-0 flex items-center justify-center ${
                selectedSection === tab
                  ? 'bg-zinc-800 text-white shadow-sm'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        <button
          onClick={() => onGenerateQuestion(selectedSection)}
          disabled={isGeneratingAI}
          className="flex items-center justify-center gap-2 px-3.5 py-2 sm:py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-100 border border-zinc-700 text-xs font-medium transition-colors disabled:opacity-50 min-h-[38px] sm:min-h-0"
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-300" />
          <span>{isGeneratingAI ? 'Synthesizing...' : 'Generate New CAT Problem (AI)'}</span>
        </button>
      </div>

      {/* Main Question Card */}
      <div className="p-4 sm:p-6 rounded-xl border border-[#27272a] bg-[#121215] space-y-4 sm:space-y-5">
        {/* Unboxed Metadata (Zero-pill discipline) */}
        <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-zinc-400">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="font-semibold text-zinc-200">{currentQ.exam}</span>
            <span aria-hidden="true" className="text-zinc-600">·</span>
            <span className="text-zinc-300">{currentQ.section}</span>
            <span aria-hidden="true" className="text-zinc-600">·</span>
            <span className="font-mono text-zinc-400">{currentQ.difficulty}</span>
          </div>
          <span className="font-mono text-zinc-500 tabular-nums shrink-0 text-[11px] sm:text-xs">
            Set {activeIdx + 1} of {questions.length}
          </span>
        </div>

        {/* Title & Body */}
        <div>
          <h2 className="text-base sm:text-lg font-semibold text-zinc-100 leading-snug">
            {currentQ.title}
          </h2>
          <p className="mt-2.5 sm:mt-3 text-zinc-300 leading-relaxed text-xs sm:text-sm whitespace-pre-line font-sans">
            {currentQ.text}
          </p>
        </div>

        {/* Input Selector: MCQ or TITA */}
        {currentQ.type === 'mcq' && currentQ.options ? (
          <div className="space-y-2 pt-1">
            {currentQ.options.map((opt, idx) => {
              const isSelected = userAnswer === opt;
              const letter = String.fromCharCode(65 + idx);
              return (
                <div
                  key={idx}
                  onClick={() => setUserAnswer(opt)}
                  className={`flex items-center gap-3 p-3 sm:p-3.5 rounded-lg border cursor-pointer transition-all min-h-[44px] ${
                    isSelected
                      ? 'border-zinc-400 bg-zinc-800/80 text-white'
                      : 'border-[#27272a] bg-[#09090b] hover:border-zinc-700 text-zinc-300'
                  }`}
                >
                  <div
                    className={`w-6 h-6 rounded flex items-center justify-center font-mono text-xs font-semibold shrink-0 ${
                      isSelected
                        ? 'bg-zinc-200 text-zinc-950'
                        : 'bg-zinc-800 text-zinc-400 border border-zinc-700'
                    }`}
                  >
                    {letter}
                  </div>
                  <span className="text-xs sm:text-sm leading-normal">{opt}</span>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="pt-1">
            <label className="block text-zinc-400 text-xs mb-1.5 font-mono">
              TITA Input (Type In The Exact Numerical Answer):
            </label>
            <input
              type="text"
              value={userAnswer}
              onChange={(e) => setUserAnswer(e.target.value)}
              placeholder="e.g. 2, 36, 120"
              className="w-full bg-[#09090b] border border-[#27272a] rounded-lg px-3.5 py-2.5 text-zinc-100 text-sm focus:outline-none focus:border-zinc-500 font-mono min-h-[44px]"
            />
          </div>
        )}

        {/* Action Controls - Mobile / Tablet / PC friendly */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-4 border-t border-[#27272a]">
          <div className="flex items-center gap-2.5">
            <button
              onClick={handleVerify}
              className="flex-1 sm:flex-initial px-4 py-2.5 sm:py-2 bg-zinc-100 hover:bg-white text-zinc-950 font-semibold rounded-lg text-xs sm:text-sm transition-colors whitespace-nowrap min-h-[40px] flex items-center justify-center"
            >
              Submit Answer
            </button>
            <button
              onClick={handleNext}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3.5 py-2.5 sm:py-2 border border-[#27272a] hover:border-zinc-600 text-zinc-300 rounded-lg text-xs sm:text-sm transition-colors whitespace-nowrap min-h-[40px]"
            >
              <span>Skip / Next</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
          <span className="text-[11px] text-zinc-500 font-mono text-center sm:text-right">
            +25 Aura on Verified Answer
          </span>
        </div>

        {/* Feedback Alert */}
        {feedback && (
          <div
            className={`p-4 rounded-lg border text-xs sm:text-sm leading-relaxed ${
              feedback.status === 'correct'
                ? 'border-emerald-500/30 bg-emerald-950/20 text-emerald-300'
                : 'border-rose-500/30 bg-rose-950/20 text-rose-300'
            }`}
          >
            <div className="flex items-center gap-2 font-semibold">
              {feedback.status === 'correct' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              ) : (
                <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
              )}
              <span>{feedback.msg}</span>
            </div>
            <div className="mt-2 text-zinc-300 whitespace-pre-line border-t border-zinc-800/60 pt-2 font-sans text-xs">
              <span className="font-semibold text-zinc-200 block mb-1">
                Invariant & Resolution Proof:
              </span>
              {currentQ.explanation}
            </div>
          </div>
        )}
      </div>

      {/* Multiverse Spillover Map Strip - Responsive Grid */}
      <div className="p-4 sm:p-5 rounded-xl border border-[#27272a] bg-[#121215]/70 space-y-3">
        <div className="flex items-center gap-2 text-xs font-semibold text-zinc-300">
          <Layers className="w-4 h-4 text-zinc-400" />
          <span>Universal Aptitude Spillover Blueprint</span>
        </div>
        <p className="text-xs text-zinc-400 leading-normal">
          Rigorous CAT preparation transfers directly across top competitive frameworks:
        </p>
        <div className="grid grid-cols-1 xs:grid-cols-2 lg:grid-cols-4 gap-2.5 text-xs">
          <div className="p-3 rounded-lg bg-[#09090b] border border-[#27272a]">
            <span className="text-zinc-200 font-semibold block">XAT (XLRI)</span>
            <span className="text-[11px] text-emerald-400 font-mono">96% Syllabus Purity</span>
          </div>
          <div className="p-3 rounded-lg bg-[#09090b] border border-[#27272a]">
            <span className="text-zinc-200 font-semibold block">UPSC CSAT</span>
            <span className="text-[11px] text-emerald-400 font-mono">100% Quant & LR Overlap</span>
          </div>
          <div className="p-3 rounded-lg bg-[#09090b] border border-[#27272a]">
            <span className="text-zinc-200 font-semibold block">SNAP / CMAT</span>
            <span className="text-[11px] text-blue-400 font-mono">Speed & Accuracy Dominance</span>
          </div>
          <div className="p-3 rounded-lg bg-[#09090b] border border-[#27272a]">
            <span className="text-zinc-200 font-semibold block">TANCET / PGCET</span>
            <span className="text-[11px] text-blue-400 font-mono">State Rank 1 Caliber</span>
          </div>
        </div>
      </div>
    </div>
  );
};
