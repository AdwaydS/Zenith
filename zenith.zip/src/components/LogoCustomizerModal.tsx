import React, { useState, useRef } from 'react';
import { createPortal } from 'react-dom';
import { X, Upload, RotateCcw, Image as ImageIcon, Check, Sparkles } from 'lucide-react';

interface LogoCustomizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLogo: string;
  isCustom: boolean;
  onUpdateLogo: (url: string) => void;
  onResetLogo: () => void;
}

export const LogoCustomizerModal: React.FC<LogoCustomizerModalProps> = ({
  isOpen,
  onClose,
  currentLogo,
  isCustom,
  onUpdateLogo,
  onResetLogo,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [urlInput, setUrlInput] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setErrorMsg('');
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrorMsg('Please select a valid image file (PNG, JPG, SVG, WebP).');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setErrorMsg('Image size should be less than 5MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (result) {
        onUpdateLogo(result);
        setSuccessMsg('Logo updated successfully from your device!');
        setTimeout(() => setSuccessMsg(''), 3000);
      }
    };
    reader.onerror = () => {
      setErrorMsg('Failed to read the image file.');
    };
    reader.readAsDataURL(file);
  };

  const handleApplyUrl = () => {
    setErrorMsg('');
    const trimmed = urlInput.trim();
    if (!trimmed) {
      setErrorMsg('Please enter an image URL.');
      return;
    }

    if (trimmed.startsWith('content://')) {
      setErrorMsg(
        'Android "content://" URIs are sandboxed to your device. Please click "Upload Image from Device" below to select that saved image file directly!'
      );
      return;
    }

    onUpdateLogo(trimmed);
    setUrlInput('');
    setSuccessMsg('Logo updated successfully!');
    setTimeout(() => setSuccessMsg(''), 3000);
  };

  const modalContent = (
    <div
      className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/85 backdrop-blur-md"
      onClick={onClose}
    >
      <div
        className="bg-[#0f172a] border border-zinc-700 rounded-2xl w-full max-w-md p-5 sm:p-6 shadow-2xl text-zinc-100 flex flex-col gap-5 relative animate-in fade-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <ImageIcon className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-semibold text-zinc-100 text-sm sm:text-base">Zenith Brand Logo</h3>
              <p className="text-[11px] text-zinc-400 font-mono">Customize or upload your logo</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Current Logo Preview */}
        <div className="flex flex-col items-center justify-center gap-3 p-5 rounded-xl bg-zinc-900/80 border border-zinc-800/80">
          <div className="relative group">
            <img
              src={currentLogo}
              alt="Zenith Logo"
              referrerPolicy="no-referrer"
              className="w-20 h-20 rounded-2xl border-2 border-zinc-700 bg-[#09090b] object-contain shadow-lg p-1.5 transition-transform group-hover:scale-105"
            />
            {isCustom && (
              <span className="absolute -top-2 -right-2 px-2 py-0.5 rounded-full bg-blue-600 text-[10px] font-mono font-semibold text-white shadow-md">
                Custom
              </span>
            )}
          </div>
          <div className="text-center">
            <div className="text-xs font-semibold text-zinc-200">
              {isCustom ? 'Custom User Logo Active' : 'Zenith Apex Emblem (Vector)'}
            </div>
            <div className="text-[11px] text-zinc-400 font-mono mt-0.5">
              Used in Header, PWA App Shell, and Meta Favicon
            </div>
          </div>
        </div>

        {/* Status Messages */}
        {errorMsg && (
          <div className="p-3 rounded-lg bg-red-950/60 border border-red-800 text-red-200 text-xs">
            {errorMsg}
          </div>
        )}
        {successMsg && (
          <div className="p-3 rounded-lg bg-emerald-950/60 border border-emerald-800 text-emerald-200 text-xs flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Actions */}
        <div className="flex flex-col gap-3">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept="image/*"
            className="hidden"
          />

          <button
            onClick={() => fileInputRef.current?.click()}
            className="w-full flex items-center justify-center gap-2.5 px-4 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 font-semibold text-white text-xs sm:text-sm shadow-md transition-all active:scale-[0.98]"
          >
            <Upload className="w-4 h-4" />
            <span>Upload Image from Device</span>
          </button>

          <p className="text-[11px] text-zinc-400 leading-relaxed px-1">
            <span className="text-zinc-300 font-medium">Tip:</span> If you generated an image via Google Assistant or Robin (e.g.{' '}
            <code className="text-[10px] bg-zinc-800 px-1 py-0.5 rounded text-zinc-300 font-mono">image_edc27553...png</code>
            ), tap above to pick it directly from your device's Downloads or Gallery.
          </p>

          <div className="relative flex py-1 items-center">
            <div className="flex-grow border-t border-zinc-800"></div>
            <span className="flex-shrink mx-3 text-zinc-400 text-[10px] uppercase font-mono tracking-wider">
              or use URL
            </span>
            <div className="flex-grow border-t border-zinc-800"></div>
          </div>

          <div className="flex gap-2">
            <input
              type="text"
              placeholder="https://... or data:image/..."
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              className="flex-1 bg-zinc-900 border border-zinc-700 rounded-xl px-3 py-2 text-xs text-zinc-200 placeholder:text-zinc-600 focus:outline-none focus:border-blue-500 font-mono"
            />
            <button
              onClick={handleApplyUrl}
              className="px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-zinc-200 transition-colors"
            >
              Apply
            </button>
          </div>

          {isCustom && (
            <button
              onClick={() => {
                onResetLogo();
                setSuccessMsg('Reset to official Zenith logo.');
                setTimeout(() => setSuccessMsg(''), 3000);
              }}
              className="flex items-center justify-center gap-2 px-3 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-xs text-zinc-400 hover:text-zinc-200 transition-colors mt-1"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset to Default Zenith Logo</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );

  return typeof document !== 'undefined' ? createPortal(modalContent, document.body) : null;
};
