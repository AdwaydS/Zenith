import React, { useState } from 'react';
import { CommunitySubmission, UserProfile, ExamSection } from '../types.ts';
import { GitPullRequest, ArrowUp, Plus, Users, CheckCircle, Code, Heart, Sparkles } from 'lucide-react';

interface CommunityHubProps {
  submissions: CommunitySubmission[];
  setSubmissions: React.Dispatch<React.SetStateAction<CommunitySubmission[]>>;
  user: UserProfile | null;
  onAwardAura: (pts: number) => void;
  auraPoints: number;
}

export const CommunityHub: React.FC<CommunityHubProps> = ({
  submissions,
  setSubmissions,
  user,
  onAwardAura,
  auraPoints,
}) => {
  const [modalOpen, setModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    exam: 'CAT',
    section: 'Quant' as ExamSection,
    text: '',
  });

  const handleUpvote = (id: string | number) => {
    setSubmissions((prev) =>
      prev.map((sub) => (sub.id === id ? { ...sub, upvotes: sub.upvotes + 1 } : sub))
    );
    onAwardAura(2);
  };

  const handleSubmitPR = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim() || !formData.text.trim()) return;

    const newSub: CommunitySubmission = {
      id: 'pr-' + Date.now(),
      author: user ? user.name.toLowerCase().replace(/\s+/g, '_') : 'guest_scholar',
      exam: formData.exam,
      section: formData.section,
      title: formData.title,
      text: formData.text,
      upvotes: 1,
      approved: true,
      createdAt: 'Just now',
    };

    setSubmissions([newSub, ...submissions]);
    onAwardAura(50);
    setModalOpen(false);
    setFormData({ title: '', exam: 'CAT', section: 'Quant', text: '' });
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-[#27272a] gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-lg sm:text-xl font-bold text-zinc-100">
              Open-Source Aptitude Repository
            </h1>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950/60 text-emerald-400 border border-emerald-800/40 hidden xs:inline">
              MIT License
            </span>
          </div>
          <p className="text-zinc-400 text-xs sm:text-sm mt-1">
            Founded by <span className="text-zinc-200 font-semibold">Adwayd</span>. A community-governed repository of peer-reviewed CAT invariants, verified shortcuts, and student pull requests.
          </p>
        </div>
        <button
          onClick={() => setModalOpen(true)}
          className="flex items-center justify-center gap-1.5 px-4 py-2.5 sm:py-2 bg-zinc-100 hover:bg-white text-zinc-950 font-semibold rounded-lg text-xs sm:text-sm transition-colors whitespace-nowrap min-h-[40px] sm:min-h-0"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Submit Pull Request</span>
        </button>
      </div>

      {/* Founder & Open-Source Banner */}
      <div className="p-4 sm:p-5 rounded-xl border border-zinc-800 bg-[#121215] flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-lg bg-zinc-900 border border-zinc-700 flex items-center justify-center font-mono font-bold text-sm text-zinc-200 shrink-0">
            <Code className="w-5 h-5 text-emerald-400" />
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-semibold text-sm text-zinc-100">
                Zenith Open Architecture
              </span>
              <span className="text-xs text-zinc-400 font-mono">
                · Founded by Adwayd (@adwayd91)
              </span>
            </div>
            <p className="text-xs text-zinc-400 leading-relaxed">
              Built on the conviction that high-rigor CAT & aptitude intelligence belongs in the open domain. All problems, sandboxes, and verification algorithms are completely open-source.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-zinc-400 self-stretch md:self-auto justify-end border-t md:border-t-0 border-zinc-800/80 pt-2 md:pt-0">
          <span className="text-emerald-400 font-semibold">● 100% Free & Open</span>
        </div>
      </div>

      {/* Main Grid: Responsive 1 col on mobile, 2 col on tablet, 3 col on PC */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Main Column: Accepted PRs (2 cols on tablet/desktop) */}
        <div className="md:col-span-2 space-y-3">
          <div className="flex items-center justify-between pb-1">
            <h2 className="text-xs font-semibold text-zinc-300 uppercase tracking-wider font-mono">
              Accepted Community PRs
            </h2>
            <span className="text-xs text-zinc-500 font-mono">{submissions.length} Total</span>
          </div>

          {submissions.map((sub) => (
            <div
              key={sub.id}
              className="p-4 sm:p-5 rounded-xl border border-[#27272a] bg-[#121215] space-y-3"
            >
              <div className="flex items-center justify-between text-xs flex-wrap gap-1">
                <span className="font-mono text-zinc-300 font-medium">@{sub.author}</span>
                <div className="flex items-center gap-2 text-zinc-500 text-[11px]">
                  <span>{sub.createdAt}</span>
                  <span className="text-zinc-400 font-mono">· {sub.exam}</span>
                  <span className="text-zinc-500 font-mono">· {sub.section}</span>
                </div>
              </div>

              <div>
                <h3 className="text-sm font-semibold text-zinc-100 leading-snug">{sub.title}</h3>
                <p className="text-xs sm:text-sm text-zinc-300 mt-2 leading-relaxed whitespace-pre-line font-sans">
                  {sub.text}
                </p>
              </div>

              <div className="flex items-center justify-between pt-2.5 border-t border-zinc-800/60 text-xs">
                <div className="flex items-center gap-1.5 text-emerald-400 font-mono text-[11px]">
                  <CheckCircle className="w-3.5 h-3.5" />
                  <span>Merged & Invariant Verified</span>
                </div>

                <button
                  onClick={() => handleUpvote(sub.id)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 text-xs transition-colors min-h-[32px]"
                >
                  <ArrowUp className="w-3.5 h-3.5 text-zinc-400" />
                  <span className="font-mono font-medium">{sub.upvotes}</span>
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Sidebar Column: Contributors Leaderboard (1 col) */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 pb-1">
            <Users className="w-4 h-4 text-zinc-400" />
            <h2 className="text-xs font-semibold text-zinc-300 uppercase tracking-wider font-mono">
              Top Contributors
            </h2>
          </div>

          <div className="p-4 sm:p-5 rounded-xl border border-[#27272a] bg-[#121215] space-y-3 text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
              <div className="flex items-center gap-2">
                <span className="text-amber-400 font-bold font-mono">👑</span>
                <span className="text-zinc-200 font-medium">adwayd (Founder)</span>
              </div>
              <span className="text-amber-300 font-mono font-semibold">2,500 Aura</span>
            </div>
            <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
              <span className="text-zinc-200 font-medium pl-6">1. siddharth_iim</span>
              <span className="text-amber-300 font-mono font-semibold">1,420 Aura</span>
            </div>
            <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
              <span className="text-zinc-200 font-medium pl-6">2. ananya_csat</span>
              <span className="text-amber-300 font-mono font-semibold">980 Aura</span>
            </div>
            <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
              <span className="text-zinc-200 font-medium pl-6">3. karthik_xat</span>
              <span className="text-amber-300 font-mono font-semibold">640 Aura</span>
            </div>
            <div className="flex items-center justify-between pt-1">
              <span className="text-zinc-300 font-medium pl-6">
                {user ? user.name : 'Your Standing'}
              </span>
              <span className="text-amber-300 font-mono font-semibold">{auraPoints} Aura</span>
            </div>
          </div>

          <div className="p-4 sm:p-5 rounded-xl border border-zinc-800 bg-[#09090b] text-xs text-zinc-400 leading-relaxed space-y-2">
            <div className="flex items-center gap-2 text-zinc-200 font-semibold">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>Contribution Bounty</span>
            </div>
            <p>
              Each merged solution awards <span className="text-zinc-200 font-mono font-medium">+50 Aura</span> to your profile. Peer upvotes award <span className="text-zinc-200 font-mono font-medium">+2 Aura</span>.
            </p>
          </div>
        </div>
      </div>

      {/* Submit PR Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
          <div className="w-full max-w-md rounded-xl border border-[#27272a] bg-[#121215] p-5 sm:p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <GitPullRequest className="w-4 h-4 text-zinc-300" />
                <h3 className="text-sm font-semibold text-zinc-100">Submit Exam Problem PR</h3>
              </div>
              <button
                onClick={() => setModalOpen(false)}
                className="text-zinc-500 hover:text-zinc-300 text-sm p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitPR} className="space-y-3 pt-1">
              <div>
                <label className="block text-[11px] text-zinc-400 mb-1 font-mono">
                  Problem Title
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Modular Ring Partition in DILR"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full bg-[#09090b] border border-[#27272a] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-zinc-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-zinc-400 mb-1 font-mono">
                    Target Exam
                  </label>
                  <select
                    value={formData.exam}
                    onChange={(e) => setFormData({ ...formData, exam: e.target.value })}
                    className="w-full bg-[#09090b] border border-[#27272a] rounded-lg px-2.5 py-2 text-xs text-white focus:outline-none focus:border-zinc-500"
                  >
                    <option value="CAT">CAT</option>
                    <option value="XAT">XAT</option>
                    <option value="UPSC CSAT">UPSC CSAT</option>
                    <option value="SNAP / CMAT">SNAP / CMAT</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] text-zinc-400 mb-1 font-mono">
                    Section
                  </label>
                  <select
                    value={formData.section}
                    onChange={(e) =>
                      setFormData({ ...formData, section: e.target.value as ExamSection })
                    }
                    className="w-full bg-[#09090b] border border-[#27272a] rounded-lg px-2.5 py-2 text-xs text-white focus:outline-none focus:border-zinc-500"
                  >
                    <option value="Quant">Quant</option>
                    <option value="DILR">DILR</option>
                    <option value="VARC">VARC</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] text-zinc-400 mb-1 font-mono">
                  Problem Text & Shortcut Proof
                </label>
                <textarea
                  rows={4}
                  required
                  placeholder="State constraints, variables, and the invariant shortcut..."
                  value={formData.text}
                  onChange={(e) => setFormData({ ...formData, text: e.target.value })}
                  className="w-full bg-[#09090b] border border-[#27272a] rounded-lg p-3 text-xs text-white focus:outline-none focus:border-zinc-500 leading-relaxed font-sans"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-zinc-100 hover:bg-white text-zinc-950 font-semibold rounded-lg text-xs transition-colors mt-2 min-h-[40px]"
              >
                Submit Pull Request (+50 Aura)
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
