import React, { useState } from 'react';
import { DILRRow } from '../types.ts';
import { validateDILRMatrix, modularExponentiation } from '../utils/engine-logic.ts';
import { Terminal, Table, Play, CheckCircle2, AlertCircle, RefreshCw } from 'lucide-react';

interface LogicSandboxesProps {
  onAwardAura: (pts: number) => void;
}

export const LogicSandboxes: React.FC<LogicSandboxesProps> = ({ onAwardAura }) => {
  // Sandbox 1: DILR State
  const initialGrid: DILRRow[] = [
    { person: 'Akash', exam: 'CAT', score: '99.8', slot: 'Slot 1' },
    { person: 'Bhavna', exam: 'XAT', score: '99.4', slot: 'Slot 2' },
    { person: 'Chetan', exam: 'CSAT', score: '135+', slot: 'Slot 3' },
    { person: 'Dev', exam: '', score: '', slot: '' },
  ];
  const [dilrGrid, setDilrGrid] = useState<DILRRow[]>(initialGrid);
  const [dilrFeedback, setDilrFeedback] = useState<{
    success: boolean;
    messages: string[];
  } | null>(null);

  // Sandbox 2: Quant Engine State
  const [calcBase, setCalcBase] = useState('3');
  const [calcExp, setCalcExp] = useState('2024');
  const [calcMod, setCalcMod] = useState('10');
  const [termOutput, setTermOutput] = useState(
    'Zenith Algorithmic Engine initialized.\nReady to evaluate modular residues, cycles, and Diophantine limits.'
  );

  // DILR Check
  const handleCheckDILR = () => {
    const result = validateDILRMatrix(dilrGrid);
    if (result.isValid) {
      setDilrFeedback({
        success: true,
        messages: [
          'Consistency established! Non-overlapping slots, exams, and candidate identities fully satisfy the constraint matrix.',
        ],
      });
      onAwardAura(30);
    } else {
      setDilrFeedback({
        success: false,
        messages: result.violations.length
          ? result.violations
          : ['Exam or slot conflict detected. Try assigning Dev to "SNAP" and "Slot 4".'],
      });
    }
  };

  const handleResetDILR = () => {
    setDilrGrid(initialGrid);
    setDilrFeedback(null);
  };

  // Modular Math Execution
  const handleRunModularCalc = () => {
    try {
      const b = BigInt(calcBase);
      const e = BigInt(calcExp);
      const m = BigInt(calcMod);

      if (m <= 0n) {
        setTermOutput('Error: Modulus must be greater than 0.');
        return;
      }

      const res = modularExponentiation(b, e, m);

      const log = [
        `>> Executing Modular Exponentiation: (${b}^${e}) mod ${m}`,
        `>> Computation Strategy: Repeated Binary Squaring (O(log n) time)`,
        `>> Calculated Remainder / Residue: ${res}`,
        `>> Invariant: By Euler Totient Theorem, a^phi(m) ≡ 1 mod m when gcd(a,m)=1.`,
        `>> Output register settled in 2ms. Result: ${res}`,
      ].join('\n');

      setTermOutput(log);
      onAwardAura(10);
    } catch (err: any) {
      setTermOutput(`>> Execution Exception: ${err.message}`);
    }
  };

  const loadPreset = (preset: 'fermat' | 'pythagoras' | 'binary') => {
    if (preset === 'fermat') {
      setCalcBase('7');
      setCalcExp('2024');
      setCalcMod('10');
    } else if (preset === 'pythagoras') {
      setCalcBase('2');
      setCalcExp('100');
      setCalcMod('7');
    } else if (preset === 'binary') {
      setCalcBase('3');
      setCalcExp('40');
      setCalcMod('100');
    }
  };

  return (
    <div className="space-y-5 sm:space-y-6">
      <div>
        <h1 className="text-lg sm:text-xl font-bold text-zinc-100">
          Interactive Logic & Mathematical Sandboxes
        </h1>
        <p className="text-zinc-400 text-xs sm:text-sm mt-1">
          Deduce complex DILR constraint cases interactively and experiment with fast modular arithmetic algorithms on any device.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 sm:gap-6 items-start">
        {/* Sandbox 1: DILR Constraint Matrix Grid */}
        <div className="p-4 sm:p-5 rounded-xl border border-[#27272a] bg-[#121215] flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
              <div className="flex items-center gap-2">
                <Table className="w-4 h-4 text-zinc-300 shrink-0" />
                <h2 className="text-sm font-semibold text-zinc-200">
                  DILR Constraint Matrix Sandbox
                </h2>
              </div>
              <span className="text-[11px] font-mono text-zinc-500">Caselet: Exam Slots</span>
            </div>

            <p className="text-xs text-zinc-400 mt-3 leading-relaxed">
              Four candidates (Akash, Bhavna, Chetan, Dev) take distinct exams in distinct slots. Dev’s parameters are missing. Complete Dev’s row without colliding with existing allocations.
            </p>

            {/* Interactive Table with smooth mobile scroll wrapper */}
            <div className="overflow-x-auto mt-4 border border-[#27272a] rounded-lg -mx-1 sm:mx-0">
              <table className="w-full text-left text-xs font-mono min-w-[320px]">
                <thead className="bg-[#09090b] text-zinc-400 border-b border-[#27272a]">
                  <tr>
                    <th className="p-2 sm:p-2.5 font-medium">Candidate</th>
                    <th className="p-2 sm:p-2.5 font-medium">Exam Track</th>
                    <th className="p-2 sm:p-2.5 font-medium">Target Score</th>
                    <th className="p-2 sm:p-2.5 font-medium">Time Slot</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#27272a] text-zinc-300">
                  {dilrGrid.map((row, idx) => (
                    <tr key={idx} className="bg-[#121215]">
                      <td className="p-2 sm:p-2.5 font-semibold text-zinc-200">{row.person}</td>
                      <td className="p-2 sm:p-2.5">
                        {idx === 3 ? (
                          <input
                            type="text"
                            value={row.exam}
                            placeholder="e.g. SNAP"
                            onChange={(e) => {
                              const newGrid = [...dilrGrid];
                              newGrid[3].exam = e.target.value;
                              setDilrGrid(newGrid);
                            }}
                            className="bg-[#09090b] border border-zinc-700 rounded px-2 py-1 text-xs w-20 sm:w-24 text-zinc-100 focus:outline-none focus:border-zinc-400"
                          />
                        ) : (
                          row.exam
                        )}
                      </td>
                      <td className="p-2 sm:p-2.5">
                        {idx === 3 ? (
                          <input
                            type="text"
                            value={row.score}
                            placeholder="98.5"
                            onChange={(e) => {
                              const newGrid = [...dilrGrid];
                              newGrid[3].score = e.target.value;
                              setDilrGrid(newGrid);
                            }}
                            className="bg-[#09090b] border border-zinc-700 rounded px-2 py-1 text-xs w-16 sm:w-20 text-zinc-100 focus:outline-none focus:border-zinc-400"
                          />
                        ) : (
                          row.score
                        )}
                      </td>
                      <td className="p-2 sm:p-2.5">
                        {idx === 3 ? (
                          <input
                            type="text"
                            value={row.slot}
                            placeholder="Slot 4"
                            onChange={(e) => {
                              const newGrid = [...dilrGrid];
                              newGrid[3].slot = e.target.value;
                              setDilrGrid(newGrid);
                            }}
                            className="bg-[#09090b] border border-zinc-700 rounded px-2 py-1 text-xs w-20 sm:w-24 text-zinc-100 focus:outline-none focus:border-zinc-400"
                          />
                        ) : (
                          row.slot
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Matrix Validation Output */}
            {dilrFeedback && (
              <div
                className={`mt-4 p-3 rounded-lg border text-xs leading-relaxed ${
                  dilrFeedback.success
                    ? 'border-emerald-500/30 bg-emerald-950/20 text-emerald-300'
                    : 'border-rose-500/30 bg-rose-950/20 text-rose-300'
                }`}
              >
                <div className="flex items-center gap-1.5 font-semibold mb-1">
                  {dilrFeedback.success ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                  )}
                  <span>
                    {dilrFeedback.success
                      ? 'Constraint Verification Passed'
                      : 'Matrix Rule Violations'}
                  </span>
                </div>
                <ul className="list-disc list-inside space-y-0.5 text-zinc-300 font-sans">
                  {dilrFeedback.messages.map((m, i) => (
                    <li key={i}>{m}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-3 border-t border-zinc-800">
            <button
              onClick={handleResetDILR}
              className="flex items-center justify-center gap-1.5 px-3 py-2 text-zinc-400 hover:text-zinc-200 text-xs transition-colors min-h-[38px] sm:min-h-0"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Reset Grid</span>
            </button>
            <button
              onClick={handleCheckDILR}
              className="px-4 py-2.5 sm:py-2 bg-zinc-100 hover:bg-white text-zinc-950 font-semibold rounded-lg text-xs transition-colors min-h-[40px] flex items-center justify-center text-center"
            >
              Evaluate Constraint Matrix (+30 Aura)
            </button>
          </div>
        </div>

        {/* Sandbox 2: Quant & Vedic Scratchpad */}
        <div className="p-4 sm:p-5 rounded-xl border border-[#27272a] bg-[#121215] flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-zinc-300 shrink-0" />
                <h2 className="text-sm font-semibold text-zinc-200">
                  Vedic & Algorithmic Math Scratchpad
                </h2>
              </div>
              <span className="text-[11px] font-mono text-zinc-500">Fast Modulo Engine</span>
            </div>

            <p className="text-xs text-zinc-400 mt-3 leading-relaxed">
              Test modular exponentiation shortcuts `(bᵉ mod m)` used extensively in CAT numbers, remainder theorem, and Euler’s Totient sets.
            </p>

            {/* Presets */}
            <div className="flex items-center gap-1.5 mt-3 flex-wrap">
              <span className="text-[11px] text-zinc-500">Presets:</span>
              <button
                onClick={() => loadPreset('fermat')}
                className="px-2.5 py-1 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-[11px] text-zinc-300 rounded font-mono"
              >
                7²⁰²⁴ mod 10
              </button>
              <button
                onClick={() => loadPreset('pythagoras')}
                className="px-2.5 py-1 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-[11px] text-zinc-300 rounded font-mono"
              >
                2¹⁰⁰ mod 7
              </button>
              <button
                onClick={() => loadPreset('binary')}
                className="px-2.5 py-1 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-[11px] text-zinc-300 rounded font-mono"
              >
                3⁴⁰ mod 100
              </button>
            </div>

            {/* Numerical Inputs - Adaptive Responsive Layout */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-3">
              <div>
                <label className="block text-[11px] text-zinc-400 font-mono mb-1">
                  Base (b)
                </label>
                <input
                  type="number"
                  value={calcBase}
                  onChange={(e) => setCalcBase(e.target.value)}
                  className="w-full bg-[#09090b] border border-[#27272a] rounded px-3 py-2 text-xs sm:text-sm text-zinc-100 font-mono focus:outline-none focus:border-zinc-500 min-h-[38px]"
                />
              </div>
              <div>
                <label className="block text-[11px] text-zinc-400 font-mono mb-1">
                  Exponent (e)
                </label>
                <input
                  type="number"
                  value={calcExp}
                  onChange={(e) => setCalcExp(e.target.value)}
                  className="w-full bg-[#09090b] border border-[#27272a] rounded px-3 py-2 text-xs sm:text-sm text-zinc-100 font-mono focus:outline-none focus:border-zinc-500 min-h-[38px]"
                />
              </div>
              <div>
                <label className="block text-[11px] text-zinc-400 font-mono mb-1">
                  Modulus (m)
                </label>
                <input
                  type="number"
                  value={calcMod}
                  onChange={(e) => setCalcMod(e.target.value)}
                  className="w-full bg-[#09090b] border border-[#27272a] rounded px-3 py-2 text-xs sm:text-sm text-zinc-100 font-mono focus:outline-none focus:border-zinc-500 min-h-[38px]"
                />
              </div>
            </div>

            {/* Terminal Window */}
            <div className="mt-4 p-3.5 rounded-lg bg-[#09090b] border border-[#27272a] font-mono text-[11px] text-emerald-400 whitespace-pre-wrap min-h-[90px] leading-relaxed overflow-x-auto">
              {termOutput}
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-3 border-t border-zinc-800">
            <span className="text-[11px] text-zinc-500 font-mono text-center sm:text-left">
              +10 Aura per test
            </span>
            <button
              onClick={handleRunModularCalc}
              className="flex items-center justify-center gap-1.5 px-4 py-2.5 sm:py-2 bg-zinc-100 hover:bg-white text-zinc-950 font-semibold rounded-lg text-xs sm:text-sm transition-colors min-h-[40px]"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Run Computation</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
