import React, { useState } from 'react';
import { UserProfile } from '../types.ts';
import { Zap, LogOut, Code, Compass, Image as ImageIcon } from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton.tsx';
import { useAppLogo } from '../hooks/useAppLogo.ts';
import { LogoCustomizerModal } from './LogoCustomizerModal.tsx';

import { ZenithLogo } from './ZenithLogo.tsx';

interface HeaderProps {
  currentView: string;
  setCurrentView: (view: string) => void;
  auraPoints: number;
  eloRating: number;
  user: UserProfile | null;
  activeAvatarTitle: string;
  onOpenAuth: () => void;
  onLogout: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  setCurrentView,
  auraPoints,
  eloRating,
  user,
  activeAvatarTitle,
  onOpenAuth,
  onLogout,
}) => {
  const [isLogoModalOpen, setIsLogoModalOpen] = useState(false);
  const { logoUrl, updateLogo, resetLogo, isCustom } = useAppLogo();

  const navItems = [
    { id: 'engine', label: 'Aptitude Engine' },
    { id: 'sandboxes', label: 'Logic Sandboxes' },
    { id: 'roadmap', label: 'Adaptive Roadmap' },
    { id: 'avatar', label: 'Avatar & Aura' },
    { id: 'community', label: 'Community Hub' },
  ];

  return (
    <>
      <header className="border-b border-[#27272a] bg-[#09090b]/95 backdrop-blur sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 h-14 sm:h-16 flex items-center justify-between gap-3 sm:gap-6">
          {/* Zone 1: Brand Wordmark with Logo and Founder Attribution */}
          <div className="flex items-center gap-2.5 whitespace-nowrap shrink-0">
            <div className="relative group/logo">
              <button
                type="button"
                onClick={() => setCurrentView('engine')}
                className="w-8 h-8 sm:w-9 sm:h-9 flex items-center justify-center transition-all focus:outline-none focus:ring-2 focus:ring-blue-500/50 rounded-xl"
                title="Zenith Exam Arena — Click to go to Engine"
              >
                {!isCustom ? (
                  <ZenithLogo size={36} />
                ) : (
                  <img
                    src={logoUrl}
                    alt="Zenith Logo"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-contain rounded-xl border border-zinc-700 bg-zinc-900 p-1 shadow-md"
                  />
                )}
              </button>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setIsLogoModalOpen(true);
                }}
                className="absolute -bottom-1 -right-1 z-20 w-4 h-4 rounded-full bg-blue-600 hover:bg-blue-500 border border-zinc-900 flex items-center justify-center text-white opacity-80 sm:opacity-0 group-hover/logo:opacity-100 transition-opacity shadow-sm"
                title="Customize or upload logo image"
              >
                <ImageIcon className="w-2.5 h-2.5" />
              </button>
            </div>
            <div
              className="flex flex-col cursor-pointer select-none"
              onClick={() => setCurrentView('engine')}
            >
              <div className="flex items-center gap-1.5">
                <span className="font-bold tracking-wider text-xs sm:text-sm text-zinc-100 uppercase">
                  Zenith
                </span>
                <span className="text-[10px] text-zinc-400 font-mono hidden md:inline">
                  · CAT Core
                </span>
              </div>
              <div className="flex items-center gap-1 text-[10px] text-zinc-400 font-mono">
                <span>By</span>
                <span className="text-zinc-200 font-medium">Adwayd</span>
                <span className="text-zinc-600 hidden xs:inline">·</span>
                <span className="text-emerald-400/90 hidden xs:inline">Open Source</span>
              </div>
            </div>
          </div>


        {/* Zone 2: Navigation Links (Laptop & PC) */}
        <nav className="hidden lg:flex items-center gap-5 xl:gap-7 text-sm font-medium text-zinc-400">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setCurrentView(item.id)}
              className={`whitespace-nowrap shrink-0 transition-colors py-1 ${
                currentView === item.id
                  ? 'text-zinc-100 font-semibold'
                  : 'hover:text-zinc-200'
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        {/* Navigation for Tablets (md to lg: 768px - 1024px) */}
        <nav className="hidden md:flex lg:hidden items-center gap-2 text-xs font-medium text-zinc-400">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setCurrentView(item.id)}
              className={`px-2.5 py-1.5 rounded-md whitespace-nowrap transition-colors ${
                currentView === item.id
                  ? 'bg-zinc-800 text-white font-semibold'
                  : 'hover:text-zinc-200 hover:bg-zinc-900'
              }`}
            >
              {item.label.split(' ')[0]}
            </button>
          ))}
        </nav>

        {/* Zone 3: Telemetry & User Controls */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Aura Indicator */}
          <div className="flex items-center gap-1.5 px-2 sm:px-2.5 py-1 rounded-md border border-amber-500/20 bg-amber-500/5 text-amber-300 font-mono text-xs tabular-nums">
            <Zap className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="font-semibold">{auraPoints}</span>
            <span className="text-[10px] text-amber-400/70 uppercase hidden sm:inline">
              Aura
            </span>
          </div>

          {/* Elo Rating (Laptop & PC) */}
          <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-md border border-blue-500/20 bg-blue-500/5 text-blue-300 font-mono text-xs tabular-nums">
            <span className="text-zinc-400">Elo:</span>
            <span className="font-semibold">{eloRating}</span>
          </div>

          {/* PWA Install Button */}
          <PWAInstallButton />

          {/* User Profile or Sign In */}
          {user ? (
            <div className="flex items-center gap-2 sm:gap-2.5 border-l border-zinc-800 pl-2 sm:pl-3">
              <div className="text-right hidden sm:block">
                <p className="text-xs font-medium text-zinc-200 leading-tight truncate max-w-[100px] md:max-w-[130px]">
                  {user.name}
                </p>
                <p className="text-[10px] text-zinc-400 font-mono truncate max-w-[100px] md:max-w-[130px]">
                  {activeAvatarTitle}
                </p>
              </div>
              {user.avatar ? (
                <img
                  src={user.avatar}
                  className="w-7 h-7 rounded-full border border-zinc-700 object-cover"
                  alt={user.name}
                />
              ) : (
                <div className="w-7 h-7 rounded-full bg-zinc-800 border border-zinc-700 flex items-center justify-center font-bold text-xs text-zinc-200">
                  {user.name.charAt(0)}
                </div>
              )}
              <button
                onClick={onLogout}
                className="text-zinc-500 hover:text-zinc-300 transition-colors p-1"
                title="Log out"
                aria-label="Log out"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <button
              onClick={onOpenAuth}
              className="px-3 sm:px-3.5 py-1.5 bg-zinc-100 hover:bg-white text-zinc-950 rounded-md font-semibold text-xs transition-colors whitespace-nowrap min-h-[36px] sm:min-h-0 flex items-center justify-center"
            >
              Sign In
            </button>
          )}
        </div>
      </div>

      {/* Mobile Navigation Strip (for Mobile Phones < 768px) */}
      <div className="md:hidden flex items-center overflow-x-auto gap-1.5 px-3 py-2 border-t border-zinc-800/80 text-xs font-medium text-zinc-400 scrollbar-none bg-[#09090b]">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setCurrentView(item.id)}
            className={`px-3 py-1.5 rounded-md whitespace-nowrap min-h-[38px] flex items-center justify-center transition-colors ${
              currentView === item.id
                ? 'bg-zinc-800 text-white font-semibold border border-zinc-700'
                : 'hover:text-zinc-200 hover:bg-zinc-900'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>
    </header>

    <LogoCustomizerModal
      isOpen={isLogoModalOpen}
      onClose={() => setIsLogoModalOpen(false)}
      currentLogo={logoUrl}
      isCustom={isCustom}
      onUpdateLogo={updateLogo}
      onResetLogo={resetLogo}
    />
  </>
);
};

