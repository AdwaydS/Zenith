import React from 'react';

interface ZenithLogoProps {
  size?: number;
  className?: string;
  showWordmark?: boolean;
  glow?: boolean;
}

export const ZenithLogo: React.FC<ZenithLogoProps> = ({
  size = 36,
  className = '',
  showWordmark = false,
  glow = true,
}) => {
  return (
    <div className={`inline-flex items-center gap-3 select-none ${className}`}>
      {/* Aesthetic Zenith Mark Container */}
      <div
        className="relative flex items-center justify-center shrink-0 group transition-transform duration-300 hover:scale-105"
        style={{ width: size, height: size }}
      >
        {/* Ambient Pulsing Neon Aura */}
        {glow && (
          <div
            className="absolute inset-0 rounded-2xl bg-gradient-to-tr from-cyan-500/20 via-blue-500/20 to-purple-500/20 blur-md opacity-70 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
            aria-hidden="true"
          />
        )}

        {/* Vector SVG Mark */}
        <svg
          viewBox="0 0 512 512"
          width={size}
          height={size}
          className="relative z-10 drop-shadow-[0_2px_12px_rgba(56,189,248,0.25)]"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <linearGradient id="zlBg" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#0a0d14" />
              <stop offset="50%" stop-color="#0e1526" />
              <stop offset="100%" stop-color="#07090f" />
            </linearGradient>

            <linearGradient id="zlApexGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#38bdf8" />
              <stop offset="40%" stop-color="#3b82f6" />
              <stop offset="75%" stop-color="#8b5cf6" />
              <stop offset="100%" stop-color="#c084fc" />
            </linearGradient>

            <linearGradient id="zlTopBar" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stop-color="#67e8f9" />
              <stop offset="100%" stop-color="#3b82f6" />
            </linearGradient>

            <linearGradient id="zlSlash" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#ffffff" />
              <stop offset="30%" stop-color="#60a5fa" />
              <stop offset="70%" stop-color="#8b5cf6" />
              <stop offset="100%" stop-color="#d946ef" />
            </linearGradient>

            <linearGradient id="zlBottomBar" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stop-color="#3b82f6" />
              <stop offset="100%" stop-color="#a855f7" />
            </linearGradient>
          </defs>

          {/* Canvas Squircle Plinth */}
          <rect
            x="24"
            y="24"
            width="464"
            height="464"
            rx="106"
            fill="url(#zlBg)"
            stroke="#1e293b"
            strokeWidth="4"
          />

          {/* Thin Glowing Inner Border */}
          <rect
            x="30"
            y="30"
            width="452"
            height="452"
            rx="100"
            fill="none"
            stroke="url(#zlApexGrad)"
            strokeWidth="2"
            strokeOpacity="0.45"
          />

          {/* Orbital Celestial Ring */}
          <ellipse
            cx="256"
            cy="245"
            rx="180"
            ry="75"
            fill="none"
            stroke="url(#zlApexGrad)"
            strokeWidth="2.5"
            strokeDasharray="10 8"
            strokeOpacity="0.5"
            transform="rotate(-25 256 245)"
          />

          {/* Diamond Astrolabe Apex Grid */}
          <path
            d="M 256 72 L 392 245 L 256 418 L 120 245 Z"
            fill="none"
            stroke="url(#zlApexGrad)"
            strokeWidth="1.5"
            strokeOpacity="0.25"
            strokeDasharray="4 6"
          />

          {/* Monogram Z - Top Bar */}
          <path
            d="M 134 165 L 366 165 C 378 165 384 176 376 186 L 336 230 L 210 230 L 254 180 L 140 180 C 132 180 128 172 134 165 Z"
            fill="url(#zlTopBar)"
          />
          <path
            d="M 134 165 L 366 165 L 348 180 L 140 180 Z"
            fill="#ffffff"
            opacity="0.4"
          />

          {/* Monogram Z - Power Diagonal Slash */}
          <path
            d="M 376 186 L 156 360 C 146 368 152 382 165 382 L 195 382 L 392 226 C 400 220 392 204 380 200 Z"
            fill="url(#zlSlash)"
          />

          {/* Monogram Z - Bottom Bar */}
          <path
            d="M 378 382 L 146 382 C 134 382 128 371 136 361 L 176 317 L 302 317 L 258 367 L 372 367 C 380 367 384 375 378 382 Z"
            fill="url(#zlBottomBar)"
          />

          {/* The Zenith Celestial Apex Star */}
          <g transform="translate(256, 122)">
            <path
              d="M 0 -36 L 4 -7 L 36 0 L 4 7 L 0 36 L -4 7 L -36 0 L -4 -7 Z"
              fill="#ffffff"
            />
            <circle cx="0" cy="0" r="7" fill="#ffffff" />
            <circle cx="0" cy="0" r="11" fill="#38bdf8" opacity="0.6" />
          </g>

          {/* Intersection Prism Core */}
          <polygon
            points="256,255 274,273 256,291 238,273"
            fill="#ffffff"
            opacity="0.95"
          />
          <polygon
            points="256,260 268,273 256,286 244,273"
            fill="#38bdf8"
          />
        </svg>
      </div>

      {/* Optional Integrated Wordmark */}
      {showWordmark && (
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5">
            <span className="font-bold tracking-wider text-base text-zinc-100 font-sans">
              ZENITH
            </span>
            <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20">
              v2.1
            </span>
          </div>
          <span className="text-[10px] text-zinc-400 font-mono tracking-tight">
            Celestial Aptitude Engine
          </span>
        </div>
      )}
    </div>
  );
};
