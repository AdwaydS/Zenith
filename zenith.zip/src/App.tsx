/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  Question,
  RoadmapWeek,
  AvatarItem,
  UserProfile,
  CommunitySubmission,
} from './types.ts';
import {
  SEED_QUESTIONS,
  TWO_MONTH_ROADMAP,
  AVATAR_ITEMS,
  INITIAL_COMMUNITY_SUBMISSIONS,
} from './data/seedData.ts';
import { calculateAuraAndElo } from './utils/engine-logic.ts';
import { Header } from './components/Header.tsx';
import { AptitudeArena } from './components/AptitudeArena.tsx';
import { AiMentorChat } from './components/AiMentorChat.tsx';
import { LogicSandboxes } from './components/LogicSandboxes.tsx';
import { AdaptiveRoadmap } from './components/AdaptiveRoadmap.tsx';
import { AvatarWorkshop } from './components/AvatarWorkshop.tsx';
import { CommunityHub } from './components/CommunityHub.tsx';
import { AuthModal } from './components/AuthModal.tsx';
import {
  auth,
  db,
  onAuthStateChanged,
  signOut,
  doc,
  getDoc,
  setDoc,
  updateDoc,
} from './lib/firebase.ts';
import { Sparkles, BookOpen, Bot } from 'lucide-react';

export default function App() {
  // Authentication & Profile State
  const [user, setUser] = useState<UserProfile | null>(() => {
    try {
      const saved = localStorage.getItem('zenith_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [authModalOpen, setAuthModalOpen] = useState(false);

  // Core Progression State
  const [currentView, setCurrentView] = useState<string>('engine');
  const [mobileSubTab, setMobileSubTab] = useState<'problem' | 'mentor'>('problem');
  const [auraPoints, setAuraPoints] = useState<number>(() => {
    const pts = localStorage.getItem('zenith_aura');
    return pts ? parseInt(pts, 10) : 480;
  });
  const [eloRating, setEloRating] = useState<number>(() => {
    const elo = localStorage.getItem('zenith_elo');
    return elo ? parseInt(elo, 10) : 1824;
  });
  const [streak] = useState<number>(7);
  const [activeAvatarTitle, setActiveAvatarTitle] = useState<string>(() => {
    return localStorage.getItem('zenith_title') || 'Vedic Math Whisperer';
  });

  // Questions & Aptitude Engine State
  const [selectedSection, setSelectedSection] = useState<string>('All');
  const [questionsList, setQuestionsList] = useState<Question[]>(SEED_QUESTIONS);
  const [activeQuestionIdx, setActiveQuestionIdx] = useState<number>(0);
  const [isGeneratingAI, setIsGeneratingAI] = useState<boolean>(false);

  // Items & Roadmap State
  const [avatarItems, setAvatarItems] = useState<AvatarItem[]>(() => {
    try {
      const saved = localStorage.getItem('zenith_avatar_items');
      return saved ? JSON.parse(saved) : AVATAR_ITEMS;
    } catch {
      return AVATAR_ITEMS;
    }
  });
  const [roadmap] = useState<RoadmapWeek[]>(TWO_MONTH_ROADMAP);

  // Community Submissions State
  const [communitySubmissions, setCommunitySubmissions] = useState<CommunitySubmission[]>(() => {
    try {
      const saved = localStorage.getItem('zenith_community_prs');
      return saved ? JSON.parse(saved) : INITIAL_COMMUNITY_SUBMISSIONS;
    } catch {
      return INITIAL_COMMUNITY_SUBMISSIONS;
    }
  });

  // Firebase Auth State Listener & Firestore Profile Sync
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        try {
          const userDocRef = doc(db, 'users', fbUser.uid);
          const userDoc = await getDoc(userDocRef);

          const defaultName =
            fbUser.displayName ||
            (fbUser.email ? fbUser.email.split('@')[0] : null) ||
            (fbUser.phoneNumber ? `Scholar #${fbUser.phoneNumber.slice(-4)}` : 'Scholar');

          if (userDoc.exists()) {
            const data = userDoc.data();
            if (data.auraPoints !== undefined) setAuraPoints(data.auraPoints);
            if (data.eloRating !== undefined) setEloRating(data.eloRating);
            if (data.activeAvatarTitle) setActiveAvatarTitle(data.activeAvatarTitle);

            setUser({
              uid: fbUser.uid,
              name: data.displayName || defaultName,
              email: fbUser.email,
              phoneNumber: fbUser.phoneNumber,
              avatar: fbUser.photoURL || null,
              tier: data.tier || 'CAT / Multiverse Aspirant',
            });
          } else {
            // First time login - initialize user record in Firestore
            await setDoc(userDocRef, {
              uid: fbUser.uid,
              displayName: defaultName,
              email: fbUser.email || null,
              phoneNumber: fbUser.phoneNumber || null,
              photoURL: fbUser.photoURL || null,
              auraPoints: 530, // 480 base + 50 signup reward
              eloRating: 1824,
              activeAvatarTitle: 'Vedic Math Whisperer',
              tier: 'CAT / Multiverse Aspirant',
              createdAt: new Date().toISOString(),
              lastLoginAt: new Date().toISOString(),
            });

            setUser({
              uid: fbUser.uid,
              name: defaultName,
              email: fbUser.email,
              phoneNumber: fbUser.phoneNumber,
              avatar: fbUser.photoURL || null,
              tier: 'CAT / Multiverse Aspirant',
            });
            setAuraPoints((prev) => prev + 50);
          }
        } catch (err) {
          console.error('Error synchronizing user profile with Firestore:', err);
        }
      }
    });

    return () => unsubscribe();
  }, []);

  // Sync state changes to Firestore if user is authenticated
  useEffect(() => {
    if (user?.uid) {
      const userDocRef = doc(db, 'users', user.uid);
      updateDoc(userDocRef, {
        auraPoints,
        eloRating,
        activeAvatarTitle,
        lastActiveAt: new Date().toISOString(),
      }).catch((err) => {
        // Silently catch or retry if doc is creating
      });
    }
  }, [auraPoints, eloRating, activeAvatarTitle, user?.uid]);

  // LocalStorage Sync
  useEffect(() => {
    localStorage.setItem('zenith_aura', auraPoints.toString());
  }, [auraPoints]);

  useEffect(() => {
    localStorage.setItem('zenith_elo', eloRating.toString());
  }, [eloRating]);

  useEffect(() => {
    localStorage.setItem('zenith_title', activeAvatarTitle);
  }, [activeAvatarTitle]);

  useEffect(() => {
    localStorage.setItem('zenith_avatar_items', JSON.stringify(avatarItems));
  }, [avatarItems]);

  useEffect(() => {
    localStorage.setItem('zenith_community_prs', JSON.stringify(communitySubmissions));
  }, [communitySubmissions]);

  useEffect(() => {
    if (user) {
      localStorage.setItem('zenith_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('zenith_user');
    }
  }, [user]);

  // Auth Handlers
  const handleAuthSuccess = (newUser: UserProfile) => {
    setUser(newUser);
    setAuraPoints((prev) => prev + 50);
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (err) {
      console.warn('Sign out error:', err);
    }
    setUser(null);
  };

  // Answer Submission Handler
  const handleAnswerSubmit = (isCorrect: boolean) => {
    const outcome = calculateAuraAndElo(eloRating, auraPoints, isCorrect, 'Hard');
    setEloRating(outcome.nextElo);
    setAuraPoints(outcome.nextAura);
  };

  // AI Question Generation Handler
  const handleGenerateQuestion = async (section: string) => {
    setIsGeneratingAI(true);
    try {
      const response = await fetch('/api/gemini/generate-question', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ section }),
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const newQ: Question = await response.json();
      setQuestionsList((prev) => [newQ, ...prev]);
      setActiveQuestionIdx(0);
      setMobileSubTab('problem'); // switch to problem on mobile
    } catch (err: any) {
      console.warn('Failed to generate question via API, synthesizing locally:', err);
      const fallback: Question = {
        id: 'ai-gen-' + Date.now(),
        section: section === 'All' ? 'Quant' : (section as any),
        exam: 'CAT / XAT',
        difficulty: 'CAT 99.8%ile Master',
        title: 'Polygonal Inradii & Optimization',
        text: 'A regular hexagon and an equilateral triangle share the exact same perimeter P. Let A_h and A_t represent their respective areas. If A_h - A_t = 18√3 cm², find the exact perimeter P in centimeters.',
        type: 'tita',
        correctAnswer: '36',
        explanation:
          'Hexagon side = a, triangle side = b. 6a = 3b => b = 2a. A_h = (3√3/2)a², A_t = √3 a². Difference = (√3/2)a² = 18√3 => a² = 36 => a = 6. Perimeter P = 6(6) = 36 cm.',
      };
      setQuestionsList((prev) => [fallback, ...prev]);
      setActiveQuestionIdx(0);
      setMobileSubTab('problem');
    } finally {
      setIsGeneratingAI(false);
    }
  };

  // Filtered Question list
  const filteredQuestions = useMemo(() => {
    if (selectedSection === 'All') return questionsList;
    return questionsList.filter((q) => q.section === selectedSection);
  }, [selectedSection, questionsList]);

  const activeQuestion =
    filteredQuestions[activeQuestionIdx] || filteredQuestions[0] || SEED_QUESTIONS[0];

  return (
    <div className="flex flex-col min-h-screen bg-[#09090b] text-[#f4f4f5]">
      {/* 3-Zone Clean Header with Founder Adwayd Attribution */}
      <Header
        currentView={currentView}
        setCurrentView={setCurrentView}
        auraPoints={auraPoints}
        eloRating={eloRating}
        user={user}
        activeAvatarTitle={activeAvatarTitle}
        onOpenAuth={() => setAuthModalOpen(true)}
        onLogout={handleLogout}
      />

      {/* Main View Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3.5 sm:p-6 lg:p-8">
        {/* VIEW 1: APTITUDE ARENA & AI MENTOR */}
        {currentView === 'engine' && (
          <div>
            {/* Tablet & Mobile Mode Switcher (shows below 1024px) */}
            <div className="lg:hidden flex items-center p-1 bg-zinc-900 rounded-lg border border-zinc-800 mb-4 max-w-md mx-auto">
              <button
                onClick={() => setMobileSubTab('problem')}
                className={`flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-semibold rounded-md transition-colors ${
                  mobileSubTab === 'problem'
                    ? 'bg-zinc-800 text-white shadow-sm'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>Problem Workspace</span>
              </button>
              <button
                onClick={() => setMobileSubTab('mentor')}
                className={`flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-semibold rounded-md transition-colors ${
                  mobileSubTab === 'mentor'
                    ? 'bg-zinc-800 text-white shadow-sm'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <Bot className="w-3.5 h-3.5 text-amber-300" />
                <span>Aura AI Mentor</span>
              </button>
            </div>

            {/* Split layout on Laptop & PC (lg+), Tabbed on Mobile & Tablet */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Problem Area */}
              <div
                className={`lg:col-span-8 ${
                  mobileSubTab === 'problem' ? 'block' : 'hidden lg:block'
                }`}
              >
                <AptitudeArena
                  questions={filteredQuestions}
                  activeIdx={activeQuestionIdx}
                  setActiveIdx={setActiveQuestionIdx}
                  selectedSection={selectedSection}
                  setSelectedSection={setSelectedSection}
                  onAnswerSubmit={handleAnswerSubmit}
                  onGenerateQuestion={handleGenerateQuestion}
                  isGeneratingAI={isGeneratingAI}
                />
              </div>

              {/* AI Mentor Area */}
              <div
                className={`lg:col-span-4 ${
                  mobileSubTab === 'mentor' ? 'block' : 'hidden lg:block'
                }`}
              >
                <AiMentorChat activeQuestion={activeQuestion} />
              </div>
            </div>
          </div>
        )}

        {/* VIEW 2: LOGIC & QUANT SANDBOXES */}
        {currentView === 'sandboxes' && (
          <LogicSandboxes onAwardAura={(pts) => setAuraPoints((prev) => prev + pts)} />
        )}

        {/* VIEW 3: ADAPTIVE 2-MONTH ROADMAP */}
        {currentView === 'roadmap' && (
          <AdaptiveRoadmap
            roadmap={roadmap}
            onSelectPractice={(section) => {
              if (section) setSelectedSection(section);
              setCurrentView('engine');
            }}
            userElo={eloRating}
            onAwardAura={(pts) => setAuraPoints((prev) => prev + pts)}
          />
        )}

        {/* VIEW 4: RPG AVATAR & AURA ECONOMY */}
        {currentView === 'avatar' && (
          <AvatarWorkshop
            user={user}
            auraPoints={auraPoints}
            setAuraPoints={setAuraPoints}
            eloRating={eloRating}
            streak={streak}
            activeAvatarTitle={activeAvatarTitle}
            setActiveAvatarTitle={setActiveAvatarTitle}
            avatarItems={avatarItems}
            setAvatarItems={setAvatarItems}
          />
        )}

        {/* VIEW 5: COMMUNITY HUB */}
        {currentView === 'community' && (
          <CommunityHub
            submissions={communitySubmissions}
            setSubmissions={setCommunitySubmissions}
            user={user}
            onAwardAura={(pts) => setAuraPoints((prev) => prev + pts)}
            auraPoints={auraPoints}
          />
        )}
      </main>

      {/* Responsive Minimalist Footer with Founder Credit */}
      <footer className="border-t border-[#27272a] py-5 px-4 sm:px-6 text-center text-xs text-zinc-500 font-mono space-y-1 bg-[#09090b]">
        <div className="flex flex-wrap items-center justify-center gap-2 text-zinc-400">
          <span className="font-semibold text-zinc-200">Zenith Engine</span>
          <span aria-hidden="true" className="text-zinc-600">·</span>
          <span>Founded by <strong className="text-zinc-200 font-semibold">Adwayd</strong></span>
          <span aria-hidden="true" className="text-zinc-600">·</span>
          <span className="text-emerald-400">Open-Source Repository</span>
        </div>
        <p className="text-[11px] text-zinc-600">
          Optimized for Mobile Phone, Tablet, Laptop & Desktop PC Displays.
        </p>
      </footer>

      {/* Auth Modal */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        onSuccess={handleAuthSuccess}
      />
    </div>
  );
}
