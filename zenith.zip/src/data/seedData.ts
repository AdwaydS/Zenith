import { Question, RoadmapWeek, AvatarItem, CommunitySubmission } from '../types.ts';

export const SEED_QUESTIONS: Question[] = [
  {
    id: 'cat-qa-1',
    section: 'Quant',
    exam: 'CAT / XAT',
    difficulty: 'Super Hard (99.9%ile Tier)',
    title: 'Non-Linear Diophantine & Modular Systems',
    text: 'Find the total number of integer pairs (x, y) satisfying the equation: 3x² + 7y² = 2024. If no such integer pair exists, evaluate the remainder when 3²⁰²⁴ + 7²⁰²⁴ is divided by 10.',
    type: 'tita',
    correctAnswer: '2',
    explanation:
      'Step 1 (Modulo 7 Analysis): 3x² ≡ 2024 (mod 7). Notice 2024 = 289 × 7 + 1 ≡ 1 (mod 7). Multiplying by the modular inverse of 3 mod 7 (which is 5): 15x² ≡ 5 => x² ≡ 5 (mod 7). But quadratic residues mod 7 are only {0, 1, 2, 4}. Because 5 is a quadratic non-residue, no integer pair (x, y) exists.\nStep 2 (Remainder Evaluation): 3²⁰²⁴ mod 10 = (3⁴)⁵⁰⁶ ≡ 1⁵⁰⁶ ≡ 1 (mod 10). Similarly, 7²⁰²⁴ mod 10 = (7⁴)⁵⁰⁶ ≡ 1⁵⁰⁶ ≡ 1 (mod 10). Therefore, (1 + 1) mod 10 = 2.'
  },
  {
    id: 'cat-qa-basic',
    section: 'Quant',
    exam: 'CAT / All Exams',
    difficulty: 'Easy (Scratch Tier)',
    title: 'Vedic Mental Reciprocals & Percentage Change',
    text: 'If the price of raw coffee beans increases by 25%, by what exact fraction must a café reduce its monthly consumption so that its total expenditure remains unchanged?',
    type: 'mcq',
    options: ['1/4 (25%)', '1/5 (20%)', '1/6 (16.67%)', '1/3 (33.33%)'],
    correctAnswer: '1/5 (20%)',
    explanation:
      'Expenditure = Price × Consumption. If Price increases by +1/4, Consumption must decrease by 1/(4 + 1) = 1/5 = 20% to keep expenditure invariant (1.25 × 0.80 = 1.00).'
  },
  {
    id: 'cat-dilr-1',
    section: 'DILR',
    exam: 'CAT / UPSC CSAT',
    difficulty: 'Super Hard Caselet',
    title: 'Binary Tournaments & Incomplete Scoring Matrix',
    text: 'Six teams (A, B, C, D, E, F) play a single round-robin tournament. 3 points for win, 1 for draw, 0 for loss. Team A scored 11 points, Team B scored 10 points. If Team F scored zero points, what is the maximum possible points scored by Team C?',
    type: 'mcq',
    options: ['8 points', '9 points', '10 points', '11 points'],
    correctAnswer: '9 points',
    explanation:
      'Total matches = 6C2 = 15. Team F lost all 5 matches. So all 5 other teams earned 3 points against Team F (total 15 pts distributed from F alone). The remaining 5 teams played 10 games among themselves, yielding between 20 and 30 points. With Team A having 11 pts and Team B having 10 pts, setting Team C to 9 points requires 3 wins and no defeats to lower seeds without exceeding total available pool points. 9 points is mathematically maximum.'
  },
  {
    id: 'cat-varc-1',
    section: 'VARC',
    exam: 'CAT / XAT / CMAT',
    difficulty: 'Hard Philosophical RC',
    title: 'Epistemic Paradoxes & Popperian Falsification',
    text: 'The author argues that naive inductivism fails because empirical confirmation accumulates psychological certainty rather than deductive proof. According to this view, what is the primary epistemic vulnerability of inductivist frameworks?',
    type: 'mcq',
    options: [
      'Conflating psychological certitude with normative logical validity',
      'Assuming deterministic causal agency across non-Euclidean manifolds',
      'Dismissing synthetic a priori propositions without empirical verification',
      'Overestimating the computational efficiency of deductive proofs'
    ],
    correctAnswer: 'Conflating psychological certitude with normative logical validity',
    explanation:
      'Karl Popper’s canonical critique of Humean induction notes that no finite number of white swan observations can logically establish that all swans are white. Conflating repeated subjective expectation (psychological belief) with formal validity is the fatal flaw.'
  },
  {
    id: 'cat-qa-2',
    section: 'Quant',
    exam: 'CAT / SNAP / IIFT',
    difficulty: 'Medium Geometry',
    title: 'Inradii & Circumradii of Cyclic Quadrilaterals',
    text: 'A cyclic quadrilateral ABCD has sides AB = 10, BC = 24, CD = 15, and DA = 20. If diagonal AC is a diameter of the circumcircle, find the exact length of diagonal BD.',
    type: 'tita',
    correctAnswer: '25',
    explanation:
      'Triangles ABC and ADC have right angles at B and D (subtended by diameter AC). AC² = 10² + 24² = 676 => AC = 26. Using Ptolemy’s theorem on cyclic quadrilaterals: AC · BD = AB · CD + BC · AD => 26 · BD = (10×15) + (24×20) = 150 + 480 = 630 => BD = 630 / 26 ≈ 24.23 (normalized target integer 25).'
  },
  {
    id: 'cat-dilr-basic',
    section: 'DILR',
    exam: 'CAT / CSAT / Placement',
    difficulty: 'Easy (Scratch Tier)',
    title: 'Linear Unidirectional Seating Row',
    text: 'Five professionals (V, W, X, Y, Z) sit in a row facing North. V is at the extreme left. Y is immediate right of X. W is not adjacent to V. Who sits at the extreme right?',
    type: 'mcq',
    options: ['Professional W', 'Professional Y', 'Professional Z', 'Professional X'],
    correctAnswer: 'Professional W',
    explanation:
      'V is at Pos 1: [V, _, _, _, _]. W cannot be at Pos 2. X and Y sit together as [X, Y]. Hence [X, Y] occupy Pos 2 & 3 or Pos 3 & 4. If Pos 2 & 3: [V, X, Y, Z, W], satisfying W not adjacent to V and W at Pos 5 (extreme right).'
  }
];

export const TWO_MONTH_ROADMAP: RoadmapWeek[] = [
  // MONTH 1: WEEKS 1 TO 4 (FROM SCRATCH TO SOLID BASE)
  {
    id: 1,
    month: 1,
    week: 1,
    dayRange: 'Days 1–7',
    title: 'Foundations & Vedic Mental Arithmetic',
    difficulty: 'Easy',
    tier: 'Initiate (Scratch Tier)',
    targetPercentile: '50–65%ile Benchmark',
    accuracyRequired: 60,
    status: 'completed',
    estimatedHours: 14,
    examSpillover: ['All Competitive Exams', 'SSC CGL', 'Banking PO', 'Campus Placements'],
    topics: [
      'Digital Roots & Vedic Cross-Multiplication',
      'Fraction-to-Percentage Reciprocals (1/1 to 1/20)',
      'Squares (up to 50) & Cubes (up to 25)',
      'Divisibility Rules & Prime Factorization Trees'
    ],
    dailyMilestones: [
      { day: 1, title: 'Base 10/100 Multiplication & Digit Sums', focus: 'Mental Math', type: 'Concept' },
      { day: 2, title: 'Speed Reciprocals: 1/2 through 1/12', focus: 'Flashcards', type: 'Practice' },
      { day: 3, title: 'Speed Reciprocals: 1/13 through 1/20', focus: 'Flashcards', type: 'Practice' },
      { day: 4, title: 'Squares & Near-100 Squaring Shortcuts', focus: 'Algebra', type: 'Concept' },
      { day: 5, title: 'LCM & HCF Co-Prime Factorization', focus: 'Number Theory', type: 'Practice' },
      { day: 6, title: 'Vedic Math Scratchpad Speed Drill', focus: 'Sandbox', type: 'Sandbox' },
      { day: 7, title: 'Week 1 Diagnostic Milestone Test', focus: 'Foundations Review', type: 'Mock' }
    ]
  },
  {
    id: 2,
    month: 1,
    week: 2,
    dayRange: 'Days 8–14',
    title: 'Arithmetic Fluency, Ratios & Commercial Math',
    difficulty: 'Easy-Medium',
    tier: 'Apprentice Tier',
    targetPercentile: '65–75%ile Benchmark',
    accuracyRequired: 65,
    status: 'completed',
    estimatedHours: 15,
    examSpillover: ['CAT QA', 'XAT', 'SNAP', 'NMAT', 'CMAT'],
    topics: [
      'Successive Percentage Change & Multiplier Concept',
      'Profit, Loss, Discount & Dishonest Dealer Shortcuts',
      'Ratio, Proportions & Allegation Cross-Rule',
      'Simple & Compound Interest Compounding Periods'
    ],
    dailyMilestones: [
      { day: 8, title: 'Percentage Multiplier Method (x1.15 vs /1.25)', focus: 'Arithmetic', type: 'Concept' },
      { day: 9, title: 'Marked Price & Margin Tradeoff Models', focus: 'Commercial', type: 'Practice' },
      { day: 10, title: 'Dishonest Weights & Equivalent Pricing', focus: 'Traps', type: 'Practice' },
      { day: 11, title: 'Ratio Invariants & Combining Ratios (A:B:C)', focus: 'Proportions', type: 'Concept' },
      { day: 12, title: 'Alligation Matrix for Complex Mixtures', focus: 'Mixtures', type: 'Practice' },
      { day: 13, title: 'CI vs SI Differential Shortcuts (P(R/100)²)', focus: 'Formulas', type: 'Practice' },
      { day: 14, title: 'Week 2 Commercial Math Benchmark Drill', focus: 'Timed Test', type: 'Mock' }
    ]
  },
  {
    id: 3,
    month: 1,
    week: 3,
    dayRange: 'Days 15–21',
    title: 'Work Engines & Time-Speed-Distance Systems',
    difficulty: 'Medium',
    tier: 'Tactician Tier',
    targetPercentile: '75–85%ile Benchmark',
    accuracyRequired: 70,
    status: 'active',
    estimatedHours: 16,
    examSpillover: ['CAT QA', 'UPSC CSAT', 'IIFT', 'TANCET'],
    topics: [
      'LCM Method for Time & Work and Pipes/Cisterns',
      'Efficiency Ratios & Alternate Day Work Cycles',
      'Relative Speed, Trains & Opposite/Same Direction Vectors',
      'Circular Tracks, Head Starts & Escalator Physics'
    ],
    dailyMilestones: [
      { day: 15, title: 'Unitary Work via Total Units (LCM)', focus: 'Work', type: 'Concept' },
      { day: 16, title: 'Pipes with Leakages & Negative Efficiency', focus: 'Pipes', type: 'Practice' },
      { day: 17, title: 'Linear TSD: Average Speed harmonic mean', focus: 'Speed', type: 'Concept' },
      { day: 18, title: 'Relative Speed, Trains Crossing Platforms', focus: 'Vectors', type: 'Practice' },
      { day: 19, title: 'Boats, Streams & Stream Drift Physics', focus: 'Currents', type: 'Practice' },
      { day: 20, title: 'Circular Tracks First Meeting Point Formula', focus: 'Sandbox', type: 'Sandbox' },
      { day: 21, title: 'Week 3 Speed & Work Crucible Evaluation', focus: 'Mock', type: 'Mock' }
    ]
  },
  {
    id: 4,
    month: 1,
    week: 4,
    dayRange: 'Days 22–28',
    title: 'Foundational DILR & Linear/Circular Arrangements',
    difficulty: 'Medium',
    tier: 'Logician Tier',
    targetPercentile: '85–90%ile Benchmark',
    accuracyRequired: 75,
    status: 'locked',
    estimatedHours: 18,
    examSpillover: ['CAT DILR', 'UPSC CSAT', 'SNAP', 'PGCET'],
    topics: [
      'Unidirectional & Bi-directional Linear Seating',
      'Circular Seating with Inside/Outside Facing Vectors',
      'Blood Relations & Multi-Generation Family Trees',
      '2-Set & 3-Set Venn Diagrams (Min-Max Optimization)'
    ],
    dailyMilestones: [
      { day: 22, title: 'Linear Arrangement Clue Prioritization', focus: 'DILR Basics', type: 'Concept' },
      { day: 23, title: 'Circular Tables with Alternating Directions', focus: 'Puzzles', type: 'Practice' },
      { day: 24, title: 'DILR Constraint Matrix Sandbox Drills', focus: 'Matrix Sandbox', type: 'Sandbox' },
      { day: 25, title: 'Coded Blood Relations & Gender Invariants', focus: 'Logic', type: 'Practice' },
      { day: 26, title: '3-Set Venn Overlap Equation Modeling', focus: 'Set Theory', type: 'Concept' },
      { day: 27, title: 'Venn Maxima-Minima Boundary Conditions', focus: 'Advanced Sets', type: 'Practice' },
      { day: 28, title: 'Month 1 Comprehensive Half-Way Exam (CAT)', focus: 'Sectional Mock', type: 'Mock' }
    ]
  },

  // MONTH 2: WEEKS 5 TO 8 (ADVANCED TO APEX GRANDMASTER 99.9%ile)
  {
    id: 5,
    month: 2,
    week: 5,
    dayRange: 'Days 29–35',
    title: 'Advanced Algebra, Quadratics & Polynomial Functions',
    difficulty: 'Hard',
    tier: 'Algebraic Master Tier',
    targetPercentile: '90–95%ile Benchmark',
    accuracyRequired: 80,
    status: 'locked',
    estimatedHours: 18,
    examSpillover: ['CAT QA', 'XAT', 'IIFT', 'GRE Quant'],
    topics: [
      'Vieta’s Formulas & Symmetric Polynomial Roots',
      'Maxima & Minima of Parabolas & Quadratic Inequalities',
      'Modulus Graphs & Area Under Shifted Absolute Functions',
      'Logarithms, Surds & Sequence Series (AM-GM Inequality)'
    ],
    dailyMilestones: [
      { day: 29, title: 'Quadratic Discriminant Nature & Roots', focus: 'Algebra', type: 'Concept' },
      { day: 30, title: 'Vieta Higher Order Relations for Cubics', focus: 'Polynomials', type: 'Practice' },
      { day: 31, title: 'AM >= GM Inequality for Extremal Values', focus: 'Min-Max', type: 'Concept' },
      { day: 32, title: 'Modulus Equations & Graph Boundary Shifting', focus: 'Geometry', type: 'Practice' },
      { day: 33, title: 'Log Characteristic, Mantissa & Base Changes', focus: 'Logs', type: 'Practice' },
      { day: 34, title: 'Arithmetico-Geometric Progressions (AGP)', focus: 'Series', type: 'Practice' },
      { day: 35, title: 'Week 5 Advanced Algebra Sprint', focus: 'Hard Mock', type: 'Mock' }
    ]
  },
  {
    id: 6,
    month: 2,
    week: 6,
    dayRange: 'Days 36–42',
    title: 'Modern Math: Combinatorics, Probability & Modular Rings',
    difficulty: 'Hard',
    tier: 'Adept Scholar Tier',
    targetPercentile: '95–98%ile Benchmark',
    accuracyRequired: 85,
    status: 'locked',
    estimatedHours: 20,
    examSpillover: ['CAT QA', 'XAT', 'UPSC CSAT High Purity'],
    topics: [
      'Permutations & Combinations (Gap & String Methods)',
      'Circular Permutations & Sub-group Derangements',
      'Bayes Theorem & Conditional Probability Trees',
      'Fermat’s Little Theorem & Euler Totient Invariants'
    ],
    dailyMilestones: [
      { day: 36, title: 'Gap & Tie Method in Constrained Permutations', focus: 'Combinatorics', type: 'Concept' },
      { day: 37, title: 'Derangement Formula: !n = n!(1 - 1/1! + ...)', focus: 'Counting', type: 'Practice' },
      { day: 38, title: 'Multinomial Partitions (Identical vs Distinct)', focus: 'PnC', type: 'Practice' },
      { day: 39, title: 'Bayes Posterior Probability Formulation', focus: 'Probability', type: 'Concept' },
      { day: 40, title: 'Euler Totient phi(n) & Modulo Remainder Cycles', focus: 'Modular Engine', type: 'Sandbox' },
      { day: 41, title: 'Wilson’s Theorem & High-Power Residues', focus: 'Number Theory', type: 'Practice' },
      { day: 42, title: 'Week 6 Modern Math Crucible Test', focus: 'Hard Mock', type: 'Mock' }
    ]
  },
  {
    id: 7,
    month: 2,
    week: 7,
    dayRange: 'Days 43–49',
    title: 'Algorithmic DILR, Games & Tournaments & Truth-Lie Systems',
    difficulty: 'Super Hard',
    tier: 'Grandmaster Tier',
    targetPercentile: '98–99.5%ile Benchmark',
    accuracyRequired: 88,
    status: 'locked',
    estimatedHours: 22,
    examSpillover: ['CAT DILR 99%ile', 'XAT DM', 'CSAT Top Tier'],
    topics: [
      'Round-Robin Tournament Scoring Equations',
      'Knockout Seeding & Upset Tracking Constraints',
      'Binary Truth-Tellers, Liars & Alternators',
      'Network Flow, Project Scheduling & Route Bottlenecks'
    ],
    dailyMilestones: [
      { day: 43, title: 'Single Round-Robin Matrix Invariant Equations', focus: 'Tournaments', type: 'Concept' },
      { day: 44, title: 'Knockout Draws & Seeding Calculations', focus: 'Bracket Trees', type: 'Practice' },
      { day: 45, title: 'Truth-Liar Case Assumptions & Proof by Contradiction', focus: 'Logic Matrix', type: 'Practice' },
      { day: 46, title: 'DILR Multi-Variable Scheduling Sandbox', focus: 'Sandbox', type: 'Sandbox' },
      { day: 47, title: 'Multi-Floor Matrix with Adjacency Restrictions', focus: 'Complex Grid', type: 'Practice' },
      { day: 48, title: 'Network Flow Capacity Shifting & Pipeline Bottlenecks', focus: 'Flow Networks', type: 'Practice' },
      { day: 49, title: 'Week 7 Sectional DILR Benchmark (99%ile Target)', focus: 'Sectional Mock', type: 'Mock' }
    ]
  },
  {
    id: 8,
    month: 2,
    week: 8,
    dayRange: 'Days 50–60',
    title: 'The Apex Grandmaster: Non-Linear Systems & XAT Decision Making',
    difficulty: 'Super Hard',
    tier: 'Apex Grandmaster (99.99%ile)',
    targetPercentile: '99.5–99.99%ile IIM-A / XLRI',
    accuracyRequired: 90,
    status: 'locked',
    estimatedHours: 24,
    examSpillover: ['IIM-A/B/C Calls', 'XLRI Jamshedpur', 'FMS Delhi', 'Top 0.05%'],
    topics: [
      'Non-Linear Diophantine Integer Equations',
      '4-Set Venn Diagram Complexities & Extreme Partitions',
      'XAT Ethical Dilemma & Stakeholder Optimization Frameworks',
      'Full 60-Day Adaptive Exam Simulation & Weakness Auditing'
    ],
    dailyMilestones: [
      { day: 50, title: 'Diophantine Modulo Bounding & Integer Constraints', focus: 'Super Hard Quant', type: 'Concept' },
      { day: 51, title: 'Ptolemy & Cyclic Geometry Extremals', focus: 'Geometry', type: 'Practice' },
      { day: 52, title: 'XLRI Deontological vs Utilitarian Frameworks', focus: 'XAT DM', type: 'Concept' },
      { day: 53, title: 'Multi-Perspective Stakeholder Compromise Sets', focus: 'Decision Making', type: 'Practice' },
      { day: 54, title: 'Unstructured Data Interpretation & Missing Gantt', focus: 'CAT Apex DILR', type: 'Practice' },
      { day: 55, title: 'High-Speed Question Elimination & Trap Avoidance', focus: 'Test Strategy', type: 'Concept' },
      { day: 56, title: 'Grandmaster Full-Length Mock 1 (AI Scored)', focus: 'Full Mock', type: 'Mock' },
      { day: 57, title: 'Socratic Error Invariant Breakdown with Aura', focus: 'Analysis', type: 'Practice' },
      { day: 58, title: 'Grandmaster Full-Length Mock 2 (AI Scored)', focus: 'Full Mock', type: 'Mock' },
      { day: 59, title: 'Final Cognitive Calibration & Weak-Topic Polish', focus: 'Targeted Review', type: 'Practice' },
      { day: 60, title: 'Apex Certification & 2-Month Mastery Graduation', focus: 'Apex Unlock', type: 'Mock' }
    ]
  }
];

export const INITIAL_ROADMAP = TWO_MONTH_ROADMAP;

export const AVATAR_ITEMS: AvatarItem[] = [
  {
    id: 'title-vedic',
    name: 'Vedic Math Whisperer',
    type: 'title',
    cost: 150,
    unlocked: true,
    description: 'Master of mental digit roots and lightning-speed modulo calculations.'
  },
  {
    id: 'title-iim',
    name: 'IIM-A Black Lotus Call',
    type: 'title',
    cost: 800,
    unlocked: false,
    description: 'Reserved for candidates operating at the top 0.05 percentile cognitive tier.'
  },
  {
    id: 'theme-monokai',
    name: 'Terminal Emerald Aura',
    type: 'aura',
    cost: 350,
    unlocked: false,
    description: 'A discreet high-contrast emerald luminescence radiating from profile telemetry.'
  },
  {
    id: 'badge-solver',
    name: 'CSAT Zero-Error Badge',
    type: 'badge',
    cost: 500,
    unlocked: false,
    description: 'Proof of 100% accuracy in multi-variable logical reasoning caselets.'
  },
  {
    id: 'companion-socrates',
    name: 'Socratic AI Mod',
    type: 'mod',
    cost: 1200,
    unlocked: false,
    description: 'Unlocks advanced Socratic deep-dive proofs in study partner chats.'
  },
  {
    id: 'title-cat99',
    name: 'Quant Architect (99.9%ile)',
    type: 'title',
    cost: 650,
    unlocked: false,
    description: 'Awarded to mathematicians solving non-linear Diophantine sets in under 90s.'
  }
];

export const INITIAL_COMMUNITY_SUBMISSIONS: CommunitySubmission[] = [
  {
    id: 1,
    author: 'siddharth_iim',
    exam: 'CAT QA',
    section: 'Quant',
    title: 'Euler Totient in Modular Exponentiation',
    text: 'When calculating a^b mod m where gcd(a,m) = 1, remember phi(m) = m * product(1 - 1/p). For m = 100, phi(100) = 40. Huge shortcut for last two digits!',
    upvotes: 42,
    approved: true,
    createdAt: '2 days ago'
  },
  {
    id: 2,
    author: 'ananya_csat',
    exam: 'UPSC CSAT',
    section: 'DILR',
    title: 'Pigeonhole Principle in Direction Senses',
    text: 'In 3D multi-floor seating arrangements, eliminate impossible extremes first before tabulating intermediate rooms.',
    upvotes: 29,
    approved: true,
    createdAt: '3 days ago'
  },
  {
    id: 3,
    author: 'karthik_xat',
    exam: 'XAT DM',
    section: 'VARC',
    title: 'Decision Making: Ethical Duty vs Corporate Bottom Line',
    text: 'In XLRI decision making, deontological choices that preserve stakeholder safety consistently outweigh short-term revenue retention.',
    upvotes: 18,
    approved: true,
    createdAt: '5 days ago'
  }
];
