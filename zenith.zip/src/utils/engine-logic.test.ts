import test from 'node:test';
import assert from 'node:assert/strict';
import {
  modularExponentiation,
  evaluateModularSumResidue,
  validateDILRMatrix,
  calculateAuraAndElo,
  evaluateRoadmapUnlock,
  purchaseAvatarItem,
  calculateCurriculumProgress,
  filterRoadmapByMonth,
} from './engine-logic.ts';
import { DILRRow, RoadmapWeek } from '../types.ts';

test('modularExponentiation computes Fermat & Euler powers accurately', () => {
  assert.equal(modularExponentiation(3n, 4n, 10n), 1n);
  assert.equal(modularExponentiation(3n, 2024n, 10n), 1n);
  assert.equal(modularExponentiation(7n, 2024n, 10n), 1n);
  assert.equal(modularExponentiation(2n, 10n, 1000n), 24n);
});

test('evaluateModularSumResidue calculates 3^2024 + 7^2024 mod 10', () => {
  const result = evaluateModularSumResidue(
    { base: 3n, exp: 2024n },
    { base: 7n, exp: 2024n },
    10n
  );
  assert.equal(result, 2n);
});

test('validateDILRMatrix detects valid non-colliding round-robin assignments', () => {
  const validGrid: DILRRow[] = [
    { person: 'Akash', exam: 'CAT', score: '99.8', slot: 'Slot 1' },
    { person: 'Bhavna', exam: 'XAT', score: '99.4', slot: 'Slot 2' },
    { person: 'Chetan', exam: 'CSAT', score: '135+', slot: 'Slot 3' },
    { person: 'Dev', exam: 'SNAP', score: '98.5', slot: 'Slot 4' },
  ];

  const check = validateDILRMatrix(validGrid);
  assert.equal(check.isValid, true);
  assert.equal(check.violations.length, 0);
});

test('validateDILRMatrix catches slot collisions and missing fields', () => {
  const collidingGrid: DILRRow[] = [
    { person: 'Akash', exam: 'CAT', score: '99.8', slot: 'Slot 1' },
    { person: 'Bhavna', exam: 'XAT', score: '99.4', slot: 'Slot 2' },
    { person: 'Chetan', exam: 'CSAT', score: '135+', slot: 'Slot 3' },
    { person: 'Dev', exam: 'CAT', score: '98.5', slot: 'Slot 1' },
  ];

  const check = validateDILRMatrix(collidingGrid);
  assert.equal(check.isValid, false);
  assert.ok(check.violations.some((v) => v.includes('Duplicate exam')));
  assert.ok(check.violations.some((v) => v.includes('Duplicate slot')));
});

test('calculateAuraAndElo awards correct deltas on right and wrong answers', () => {
  const correctResult = calculateAuraAndElo(1500, 200, true, 'Hard');
  assert.equal(correctResult.nextElo, 1516);
  assert.equal(correctResult.nextAura, 225);
  assert.equal(correctResult.auraDelta, 25);

  const incorrectResult = calculateAuraAndElo(1500, 200, false, 'Hard');
  assert.equal(incorrectResult.nextElo, 1492);
  assert.equal(incorrectResult.nextAura, 200);
});

test('calculateCurriculumProgress correctly computes phase and percentage for 2-month plan', () => {
  const early = calculateCurriculumProgress(15, 60);
  assert.equal(early.percentage, 25);
  assert.equal(early.remainingDays, 45);
  assert.ok(early.phase.includes('Month 1'));

  const late = calculateCurriculumProgress(45, 60);
  assert.equal(late.percentage, 75);
  assert.equal(late.remainingDays, 15);
  assert.ok(late.phase.includes('Month 2'));
});

test('filterRoadmapByMonth properly separates Month 1 and Month 2 weeks', () => {
  const dummyWeeks: RoadmapWeek[] = [
    { id: 1, month: 1 } as any,
    { id: 2, month: 1 } as any,
    { id: 5, month: 2 } as any,
    { id: 6, month: 2 } as any,
  ];

  assert.equal(filterRoadmapByMonth(dummyWeeks, 1).length, 2);
  assert.equal(filterRoadmapByMonth(dummyWeeks, 2).length, 2);
  assert.equal(filterRoadmapByMonth(dummyWeeks, 'all').length, 4);
});

test('purchaseAvatarItem validates transaction against Aura balance', () => {
  const success = purchaseAvatarItem(500, 350);
  assert.equal(success.success, true);
  assert.equal(success.remainingAura, 150);

  const failure = purchaseAvatarItem(200, 350);
  assert.equal(failure.success, false);
  assert.equal(failure.remainingAura, 200);
});
