import { DILRRow, RoadmapWeek } from '../types.ts';

/**
 * Computes (base^exp) % mod using fast modular exponentiation.
 */
export function modularExponentiation(base: bigint, exp: bigint, mod: bigint): bigint {
  if (mod === 1n) return 0n;
  let result = 1n;
  let b = base % mod;
  let e = exp;
  while (e > 0n) {
    if (e % 2n === 1n) {
      result = (result * b) % mod;
    }
    e = e / 2n;
    b = (b * b) % mod;
  }
  return result;
}

/**
 * Evaluates residue for Diophantine systems (e.g., 3^2024 + 7^2024 mod 10)
 */
export function evaluateModularSumResidue(
  term1: { base: bigint; exp: bigint },
  term2: { base: bigint; exp: bigint },
  mod: bigint
): bigint {
  const r1 = modularExponentiation(term1.base, term1.exp, mod);
  const r2 = modularExponentiation(term2.base, term2.exp, mod);
  return (r1 + r2) % mod;
}

/**
 * Validates DILR Round-Robin / Scheduling constraints
 */
export function validateDILRMatrix(rows: DILRRow[]): {
  isValid: boolean;
  violations: string[];
} {
  const violations: string[] = [];
  const slots = new Set<string>();
  const exams = new Set<string>();

  for (const row of rows) {
    const examClean = row.exam.trim().toUpperCase();
    const slotClean = row.slot.trim().toUpperCase();

    if (!row.person.trim()) {
      violations.push('Missing participant identity');
    }
    if (!examClean) {
      violations.push(`Participant ${row.person} has no exam assigned.`);
      continue;
    }
    if (!slotClean) {
      violations.push(`Participant ${row.person} has no slot assigned.`);
      continue;
    }

    if (exams.has(examClean)) {
      violations.push(`Duplicate exam assigned: ${examClean}`);
    } else {
      exams.add(examClean);
    }

    if (slots.has(slotClean)) {
      violations.push(`Duplicate slot collision: ${slotClean}`);
    } else {
      slots.add(slotClean);
    }
  }

  return {
    isValid: violations.length === 0,
    violations,
  };
}

/**
 * Computes updated Elo rating and Aura points after question attempt
 */
export function calculateAuraAndElo(
  currentElo: number,
  currentAura: number,
  isCorrect: boolean,
  difficultyTier: 'Easy' | 'Medium' | 'Hard' | 'Extreme' = 'Hard'
): { nextElo: number; nextAura: number; auraDelta: number; eloDelta: number } {
  const auraGains: Record<string, number> = {
    Easy: 10,
    Medium: 15,
    Hard: 25,
    Extreme: 40,
  };

  const eloGains: Record<string, number> = {
    Easy: 8,
    Medium: 12,
    Hard: 16,
    Extreme: 24,
  };

  if (isCorrect) {
    const auraDelta = auraGains[difficultyTier] || 25;
    const eloDelta = eloGains[difficultyTier] || 16;
    return {
      nextElo: currentElo + eloDelta,
      nextAura: currentAura + auraDelta,
      auraDelta,
      eloDelta,
    };
  } else {
    const eloDelta = -8;
    return {
      nextElo: Math.max(1000, currentElo + eloDelta),
      nextAura: currentAura,
      auraDelta: 0,
      eloDelta,
    };
  }
}

/**
 * Calculates curriculum progress for the 60-day 2-month roadmap
 */
export function calculateCurriculumProgress(
  completedDays: number,
  totalDays: number = 60
): { percentage: number; remainingDays: number; phase: string } {
  const percentage = Math.min(100, Math.round((completedDays / totalDays) * 100));
  const remainingDays = Math.max(0, totalDays - completedDays);
  
  let phase = 'Month 1: Ground Zero Foundations (Easy to Intermediate)';
  if (completedDays > 28) {
    phase = 'Month 2: High-Rigor Mastery to Grandmaster (Hard to Super Hard)';
  }

  return {
    percentage,
    remainingDays,
    phase,
  };
}

/**
 * Filters roadmap weeks by month
 */
export function filterRoadmapByMonth(weeks: RoadmapWeek[], month: 1 | 2 | 'all'): RoadmapWeek[] {
  if (month === 'all') return weeks;
  return weeks.filter((w) => w.month === month);
}

/**
 * Determines whether a locked roadmap level can be unlocked based on accuracy and Elo
 */
export function evaluateRoadmapUnlock(
  requiredAccuracy: number,
  userAccuracy: number,
  userElo: number,
  requiredElo: number = 1400
): boolean {
  return userAccuracy >= requiredAccuracy && userElo >= requiredElo;
}

/**
 * Validates whether user has sufficient Aura points to purchase an item
 */
export function purchaseAvatarItem(
  currentAura: number,
  cost: number
): { success: boolean; remainingAura: number; message: string } {
  if (currentAura >= cost) {
    return {
      success: true,
      remainingAura: currentAura - cost,
      message: 'Item unlocked successfully.',
    };
  }
  return {
    success: false,
    remainingAura: currentAura,
    message: `Insufficient Aura points. You need ${cost - currentAura} more Aura.`,
  };
}
