export type ExamSection = 'Quant' | 'DILR' | 'VARC';

export interface Question {
  id: string;
  section: ExamSection;
  exam: string;
  difficulty: string;
  title: string;
  text: string;
  type: 'mcq' | 'tita';
  options?: string[];
  correctAnswer: string;
  explanation: string;
}

export type RoadmapDifficulty = 'Easy' | 'Easy-Medium' | 'Medium' | 'Hard' | 'Super Hard';

export interface DailyMilestone {
  day: number;
  title: string;
  focus: string;
  type: 'Concept' | 'Practice' | 'Sandbox' | 'Mock';
}

export interface RoadmapWeek {
  id: number;
  month: 1 | 2;
  week: number;
  dayRange: string;
  title: string;
  difficulty: RoadmapDifficulty;
  tier: string;
  targetPercentile: string;
  accuracyRequired: number;
  status: 'completed' | 'active' | 'locked';
  examSpillover: string[];
  topics: string[];
  dailyMilestones: DailyMilestone[];
  estimatedHours: number;
}

export interface AvatarItem {
  id: string;
  name: string;
  type: 'title' | 'aura' | 'badge' | 'mod';
  cost: number;
  unlocked: boolean;
  description: string;
}

export interface UserProfile {
  uid?: string;
  name: string;
  email: string | null;
  phoneNumber?: string | null;
  avatar: string | null;
  tier: string;
  provider?: string;
}

export interface CommunitySubmission {
  id: string | number;
  author: string;
  exam: string;
  section: ExamSection;
  title: string;
  text: string;
  upvotes: number;
  approved: boolean;
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'aura';
  text: string;
  timestamp: string;
}

export interface DILRRow {
  person: string;
  exam: string;
  score: string;
  slot: string;
}
