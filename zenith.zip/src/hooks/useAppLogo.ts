import { useState, useEffect } from 'react';

const STORAGE_KEY = 'zenith_custom_logo';
const DEFAULT_LOGO = '/zenith-logo.svg';

export function useAppLogo() {
  const [logoUrl, setLogoUrl] = useState<string>(DEFAULT_LOGO);

  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        setLogoUrl(stored);
      }
    } catch {
      // Ignore localStorage issues
    }
  }, []);

  const updateLogo = (newUrl: string) => {
    try {
      localStorage.setItem(STORAGE_KEY, newUrl);
      setLogoUrl(newUrl);
    } catch (e) {
      console.warn('Failed to save custom logo to localStorage:', e);
      setLogoUrl(newUrl);
    }
  };

  const resetLogo = () => {
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {}
    setLogoUrl(DEFAULT_LOGO);
  };

  return {
    logoUrl,
    updateLogo,
    resetLogo,
    isCustom: logoUrl !== DEFAULT_LOGO,
  };
}
